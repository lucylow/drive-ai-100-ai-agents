def finite_difference(values,dt):
 if dt<=0: raise ValueError("dt positive required")
 return [(b-a)/dt for a,b in zip(values,values[1:])]
def jerk_from_speed(speed,dt):
 acceleration=finite_difference(speed,dt)
 return finite_difference(acceleration,dt) if len(acceleration)>1 else []
def rms(values):
 return (sum(x*x for x in values)/len(values))**.5 if values else 0.
