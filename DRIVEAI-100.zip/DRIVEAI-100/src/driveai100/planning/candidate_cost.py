def score_candidate(progress,smoothness,risk,rule_violations,weights=None):
 w=weights or {"progress":1.,"smoothness":1.,"risk":5.,"rule":10.}
 return w["progress"]*progress-w["smoothness"]*smoothness-w["risk"]*risk-w["rule"]*len(rule_violations)
