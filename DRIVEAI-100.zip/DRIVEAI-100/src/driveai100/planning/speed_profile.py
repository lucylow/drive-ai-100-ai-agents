"""Planning utility: speed profile."""
from math import sqrt
def summarize(records,field=None):
 records=list(records); values=[x.get(field) for x in records] if field else records; present=[x for x in values if x is not None]
 return {"count":len(records),"present":len(present),"missing":len(records)-len(present),"distinct":len({repr(x) for x in present})}
def validate_range(value,lower,upper,name="value"):
 number=float(value)
 if not lower<=number<=upper: raise ValueError(f"{name} outside [{lower},{upper}]")
 return number
def distance_matrix(points):
 result=[]
 for a in points:
  row=[]
  for b in points:
   if len(a)!=len(b): raise ValueError("point dimensions differ")
   row.append(sqrt(sum((float(x)-float(y))**2 for x,y in zip(a,b))))
  result.append(row)
 return result
def group_by(records,field):
 groups={}
 for item in records: groups.setdefault(item.get(field,"unknown"),[]).append(item)
 return groups
def stable_sort(records,field):
 return sorted(records,key=lambda x:(x.get(field) is None,str(x.get(field))))
