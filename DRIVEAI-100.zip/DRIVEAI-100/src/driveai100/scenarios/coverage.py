from driveai100.algorithms.scenario import coverage_report
def scenario_coverage(scenarios): return coverage_report(scenarios)
def coverage_gap_matrix(scenarios,dimensions):
 observed={d:set() for d in dimensions}
 for scenario in scenarios:
  for dimension in dimensions:
   if dimension in scenario: observed[dimension].add(str(scenario[dimension]))
 return {k:sorted(v) for k,v in observed.items()}
