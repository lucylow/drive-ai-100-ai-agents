from dataclasses import dataclass
import random
from driveai100.domain.scenario import Scenario
@dataclass
class ScenarioRange:
 traffic_density:tuple=(0.,1.); pedestrian_density:tuple=(0.,.8); visibility_m:tuple=(10.,200.); road_friction:tuple=(.25,1.); weather:tuple=("clear","cloudy","rain","fog")
class ScenarioGenerator:
 def __init__(self,seed=42,ranges=None): self.rng=random.Random(seed); self.ranges=ranges or ScenarioRange()
 def generate(self,scenario_id,map_name="Town03",seed=None):
  local_seed=self.rng.randrange(2**31) if seed is None else int(seed); rng=random.Random(local_seed); r=self.ranges
  return Scenario(scenario_id,map_name,rng.choice(r.weather),rng.uniform(*r.traffic_density),rng.uniform(*r.pedestrian_density),rng.uniform(*r.visibility_m),rng.uniform(*r.road_friction),local_seed).validate()
 def batch(self,count,map_name="Town03"):
  if not 1<=count<=10000: raise ValueError("count must be 1..10000")
  return [self.generate(f"driveai-{i:06d}",map_name) for i in range(count)]
