from copy import deepcopy
class ScenarioMutator:
 ALLOWED={"traffic_density","pedestrian_density","visibility_m","road_friction","weather"}
 def mutate(self,scenario,dimension,value):
  if dimension not in self.ALLOWED: raise ValueError("unsupported mutation dimension")
  candidate=deepcopy(scenario); candidate[dimension]=value; self.validate(candidate)
  candidate.setdefault("mutation_history",[]).append({"dimension":dimension,"value":value}); return candidate
 @staticmethod
 def validate(s):
  for key in ("traffic_density","pedestrian_density"):
   if key in s and not 0<=float(s[key])<=1: raise ValueError(f"{key} out of range")
  if "visibility_m" in s and float(s["visibility_m"])<=0: raise ValueError("visibility must be positive")
  if "road_friction" in s and not 0<float(s["road_friction"])<=1.5: raise ValueError("friction out of range")
  return True
