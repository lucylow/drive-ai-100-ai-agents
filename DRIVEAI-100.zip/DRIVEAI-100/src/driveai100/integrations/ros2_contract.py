TOPICS={"camera_front":"/driveai/camera/front","lidar_points":"/driveai/lidar/points","radar_tracks":"/driveai/radar/tracks","ego_odometry":"/driveai/ego/odometry","perception_objects":"/driveai/perception/objects","fusion_tracks":"/driveai/fusion/tracks","prediction_trajectories":"/driveai/prediction/trajectories","world_state":"/driveai/world/state","simulation_events":"/driveai/simulation/events","evaluation_findings":"/driveai/evaluation/findings"}
QOS_PROFILES={"sensor_stream":{"reliability":"best_effort","durability":"volatile","history":"keep_last","depth":5},"critical_event":{"reliability":"reliable","durability":"volatile","history":"keep_last","depth":20},"static_map":{"reliability":"reliable","durability":"transient_local","history":"keep_last","depth":1}}
def validate_topic_contract():
 if len(set(TOPICS.values()))!=len(TOPICS): raise ValueError("duplicate ROS topics")
 return {"topic_count":len(TOPICS),"valid":True}
