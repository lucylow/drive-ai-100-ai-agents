"""Read-only CARLA client adapter. No simulator control methods are exposed."""
from driveai100.errors import IntegrationUnavailable
class CarlaReadOnlyAdapter:
 def __init__(self,host="127.0.0.1",port=2000,timeout=5.): self.host=host; self.port=int(port); self.timeout=float(timeout); self.client=None
 def connect(self):
  try: import carla
  except ImportError as exc: raise IntegrationUnavailable("Install the CARLA Python API matching the server release") from exc
  self.client=carla.Client(self.host,self.port); self.client.set_timeout(self.timeout); return self.client.get_world()
 def snapshot(self):
  if self.client is None: raise RuntimeError("connect first")
  world=self.client.get_world(); snap=world.get_snapshot(); actors=[]
  for actor in world.get_actors():
   if actor.type_id.startswith(("vehicle.","walker.")):
    t=actor.get_transform(); v=actor.get_velocity(); actors.append({"actor_id":str(actor.id),"type":actor.type_id,"x":t.location.x,"y":t.location.y,"vx":v.x,"vy":v.y})
  return {"frame":snap.frame,"timestamp":snap.timestamp.elapsed_seconds,"actors":actors}
 def close(self): self.client=None
