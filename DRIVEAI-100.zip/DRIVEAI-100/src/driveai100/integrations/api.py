from pathlib import Path


def create_app(registry=None):
    try:
        from fastapi import FastAPI, HTTPException
        from fastapi.responses import FileResponse
        from fastapi.staticfiles import StaticFiles
    except ImportError as exc:
        raise RuntimeError("Install driveai100[api]") from exc

    from driveai100.agents.factory import build_registry
    from driveai100.catalog import load_catalog, validate_catalog
    from driveai100.demo import run_demo
    from driveai100.mock_data import MockDataService

    app = FastAPI(title="DRIVEAI 100 Research API", version="0.1.0")
    active_registry = registry
    mock_service = MockDataService(seed=42)

    @app.get("/health")
    def health():
        return {"status": "ok", "mode": "simulation_research_only", "demo_mode": True}

    @app.get("/agents")
    def agents():
        return [m.__dict__ for m in (active_registry.manifests() if active_registry else load_catalog())]

    @app.get("/agents/{agent_id}")
    def agent(agent_id: str):
        if active_registry and agent_id in active_registry:
            return active_registry.get(agent_id).manifest.__dict__
        match = [m for m in load_catalog() if m.agent_id == agent_id]
        if not match:
            raise HTTPException(status_code=404, detail="agent not found")
        return match[0].__dict__

    @app.get("/catalog/validate")
    def catalog():
        return validate_catalog()

    @app.get("/agent-health")
    def agent_health():
        nonlocal active_registry
        if active_registry is None:
            active_registry = build_registry()
        return {"registered": len(active_registry), "agents": [a.health() for a in active_registry._agents.values()]}

    @app.get("/demo")
    async def demo():
        return await run_demo()

    @app.get("/mock-data")
    def mock_data():
        return mock_service.snapshot()

    @app.post("/mock-data/reset")
    def reset_mock_data():
        return mock_service.reset()

    @app.post("/mock-data/scenario")
    def generate_mock_scenario():
        return mock_service.generate_scenario()

    ui_dir = Path(__file__).resolve().parents[1] / "ui"
    if ui_dir.exists():
        app.mount("/ui", StaticFiles(directory=ui_dir), name="ui")

        @app.get("/", include_in_schema=False)
        def home():
            return FileResponse(ui_dir / "index.html")

    return app
