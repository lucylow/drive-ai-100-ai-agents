from dataclasses import dataclass
@dataclass
class Hypothesis:
 question:str; expected_direction:str; independent_variable:str; dependent_variable:str; baseline:str; confounders:list
 def validate(self):
  if not all((self.question,self.expected_direction,self.independent_variable,self.dependent_variable,self.baseline)): raise ValueError("hypothesis fields required")
  return self
