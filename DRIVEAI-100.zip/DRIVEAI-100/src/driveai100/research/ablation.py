def ablation_matrix(components):
 if len(components)>12: raise ValueError("too many components for exhaustive ablation")
 rows=[]
 for mask in range(1<<len(components)):
  rows.append({"enabled":[name for i,name in enumerate(components) if mask&(1<<i)],"disabled":[name for i,name in enumerate(components) if not mask&(1<<i)]})
 return rows
