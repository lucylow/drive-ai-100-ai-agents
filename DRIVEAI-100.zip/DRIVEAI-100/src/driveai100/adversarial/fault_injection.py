def drop_frames(frames,every_n=5):
 if every_n<1: raise ValueError("every_n must be positive")
 return [frame for i,frame in enumerate(frames) if (i+1)%every_n!=0]
def add_bounded_noise(value,noise,lower,upper):
 result=value+noise
 if not lower<=result<=upper: raise ValueError("perturbation leaves declared bounds")
 return result
