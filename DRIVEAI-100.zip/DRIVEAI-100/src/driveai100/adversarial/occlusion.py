def visible_fraction(box,occluders):
 x1,y1,x2,y2=box; area=max(0,x2-x1)*max(0,y2-y1)
 if area<=0: return 0.
 covered=0.
 for a,b,c,d in occluders:
  covered+=max(0,min(x2,c)-max(x1,a))*max(0,min(y2,d)-max(y1,b))
 return max(0.,1-min(1.,covered/area))
