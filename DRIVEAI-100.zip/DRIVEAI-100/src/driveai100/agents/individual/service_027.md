# Agent 027 service wiring

- **Name:** Driver Intent Prediction
- **Family:** prediction
- **Responsibility:** Infer possible manoeuvre intentions from observed behaviour.
- **Import:** `driveai100.agents.individual.agent_027`
- **Runtime wrapper:** `driveai100.agents.individual.service_027.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
