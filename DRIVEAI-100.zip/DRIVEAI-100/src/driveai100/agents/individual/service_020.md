# Agent 020 service wiring

- **Name:** Fusion Arbitration
- **Family:** fusion
- **Responsibility:** Resolve conflicting observations and expose unresolved ambiguity.
- **Import:** `driveai100.agents.individual.agent_020`
- **Runtime wrapper:** `driveai100.agents.individual.service_020.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
