# Agent 010 service wiring

- **Name:** Perception Confidence
- **Family:** perception
- **Responsibility:** Confidence calibration, ambiguity detection, and uncertainty reporting.
- **Import:** `driveai100.agents.individual.agent_010`
- **Runtime wrapper:** `driveai100.agents.individual.service_010.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
