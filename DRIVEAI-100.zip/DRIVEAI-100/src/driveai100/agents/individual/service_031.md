# Agent 031 service wiring

- **Name:** Scenario Discovery
- **Family:** scenario
- **Responsibility:** Identify interesting or underrepresented simulation conditions.
- **Import:** `driveai100.agents.individual.agent_031`
- **Runtime wrapper:** `driveai100.agents.individual.service_031.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
