# Agent 009 service wiring

- **Name:** Weather Perception
- **Family:** perception
- **Responsibility:** Visibility, precipitation, fog, glare, and environmental degradation.
- **Import:** `driveai100.agents.individual.agent_009`
- **Runtime wrapper:** `driveai100.agents.individual.service_009.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
