# Agent 074 service wiring

- **Name:** Rule Compliance
- **Family:** safety
- **Responsibility:** Evaluate encoded simulation traffic rules.
- **Import:** `driveai100.agents.individual.agent_074`
- **Runtime wrapper:** `driveai100.agents.individual.service_074.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
