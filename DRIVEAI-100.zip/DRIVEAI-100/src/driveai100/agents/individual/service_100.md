# Agent 100 service wiring

- **Name:** Chief Research Intelligence
- **Family:** research
- **Responsibility:** Coordinate research priorities and summarize validated findings.
- **Import:** `driveai100.agents.individual.agent_100`
- **Runtime wrapper:** `driveai100.agents.individual.service_100.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
