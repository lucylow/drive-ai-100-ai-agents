# Agent 053 service wiring

- **Name:** Motion Planning
- **Family:** planning
- **Responsibility:** Generate candidate motion trajectories.
- **Import:** `driveai100.agents.individual.agent_053`
- **Runtime wrapper:** `driveai100.agents.individual.service_053.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
