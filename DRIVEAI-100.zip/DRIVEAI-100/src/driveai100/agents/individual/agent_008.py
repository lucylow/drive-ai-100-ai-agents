"""DRIVEAI Agent 008 — Cyclist and Vulnerable Road User.

Responsibility: Cyclists, motorcycles, mobility devices, and other vulnerable road users.
Family baseline: perception
"""
from driveai100.catalog import load_catalog
from driveai100.agents.factory import FAMILY_CLASSES
AGENT_ID="008"
AGENT_NAME='Cyclist and Vulnerable Road User'
RESPONSIBILITY='Cyclists, motorcycles, mobility devices, and other vulnerable road users.'
HANDLER_FAMILY="perception"
def manifest():
 return next(item for item in load_catalog() if item.agent_id==AGENT_ID)
def build():
 return FAMILY_CLASSES[HANDLER_FAMILY](manifest())
def describe():
 return {"agent_id":AGENT_ID,"name":AGENT_NAME,"responsibility":RESPONSIBILITY,"handler_family":HANDLER_FAMILY,"maturity":"L1-prototyped","simulation_only":True}
class AgentIdentity:
 """Stable dependency-injection entry point for this specialist."""
 agent_id=AGENT_ID
 name=AGENT_NAME
 responsibility=RESPONSIBILITY
 handler_family=HANDLER_FAMILY
 @classmethod
 def create(cls): return build()
 @classmethod
 def contract(cls):
  return {"agent_id":cls.agent_id,"required_payload_family":cls.handler_family,"scenario_id_required":True,"trace_id_required":True,"evidence_lineage":True,"physical_actuation":False}
