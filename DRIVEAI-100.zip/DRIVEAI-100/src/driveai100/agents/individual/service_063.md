# Agent 063 service wiring

- **Name:** Dynamic World Model
- **Family:** world
- **Responsibility:** Track changing objects and scene state.
- **Import:** `driveai100.agents.individual.agent_063`
- **Runtime wrapper:** `driveai100.agents.individual.service_063.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
