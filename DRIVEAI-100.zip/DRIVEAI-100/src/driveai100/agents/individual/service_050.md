# Agent 050 service wiring

- **Name:** Adversarial Test Coordinator
- **Family:** adversarial
- **Responsibility:** Coordinate adversarial test campaigns.
- **Import:** `driveai100.agents.individual.agent_050`
- **Runtime wrapper:** `driveai100.agents.individual.service_050.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
