"""Thin task service wrapper for agent 001: Vision Perception.
Responsibility: Image-based object detection, classification, and localization.
"""
from driveai100.core.contracts import AgentTask
from driveai100.agents.individual.agent_001 import build,describe
AGENT_ID="001"
TASK_TYPE="perception_analysis"
class Service:
 def __init__(self):
  self.agent=build(); self.identity=describe()
 async def invoke(self,scenario_id,payload,deadline_seconds=10.0,evidence=None,idempotency_key=None):
  task=AgentTask(agent_id=AGENT_ID,task_type=TASK_TYPE,scenario_id=scenario_id,payload=payload,deadline_seconds=deadline_seconds,evidence=list(evidence or []),idempotency_key=idempotency_key)
  return await self.agent.execute(task)
 def health(self): return self.agent.health()
 def acceptance_contract(self):
  return {"agent_id":AGENT_ID,"task_type":TASK_TYPE,"payload_family":"perception","must_emit_task_id":True,"must_emit_scenario_id":True,"must_preserve_evidence_ids":True,"must_fail_closed":True,"physical_actuation":False}
