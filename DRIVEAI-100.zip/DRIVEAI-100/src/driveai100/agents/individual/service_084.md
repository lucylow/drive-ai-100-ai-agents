# Agent 084 service wiring

- **Name:** Planning Benchmark
- **Family:** evaluation
- **Responsibility:** Evaluate candidate planning outputs.
- **Import:** `driveai100.agents.individual.agent_084`
- **Runtime wrapper:** `driveai100.agents.individual.service_084.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
