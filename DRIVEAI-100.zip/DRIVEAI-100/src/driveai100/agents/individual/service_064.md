# Agent 064 service wiring

- **Name:** Static Infrastructure Model
- **Family:** world
- **Responsibility:** Represent roads, curbs, signs, and fixed infrastructure.
- **Import:** `driveai100.agents.individual.agent_064`
- **Runtime wrapper:** `driveai100.agents.individual.service_064.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
