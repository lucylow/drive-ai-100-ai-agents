# Agent 083 service wiring

- **Name:** Prediction Benchmark
- **Family:** evaluation
- **Responsibility:** Evaluate trajectory prediction.
- **Import:** `driveai100.agents.individual.agent_083`
- **Runtime wrapper:** `driveai100.agents.individual.service_083.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
