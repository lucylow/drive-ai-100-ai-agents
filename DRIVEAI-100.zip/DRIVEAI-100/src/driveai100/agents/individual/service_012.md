# Agent 012 service wiring

- **Name:** Camera-LiDAR Calibration
- **Family:** fusion
- **Responsibility:** Estimate and monitor extrinsic and intrinsic calibration.
- **Import:** `driveai100.agents.individual.agent_012`
- **Runtime wrapper:** `driveai100.agents.individual.service_012.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
