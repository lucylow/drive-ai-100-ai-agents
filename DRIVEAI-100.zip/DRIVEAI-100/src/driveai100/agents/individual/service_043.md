# Agent 043 service wiring

- **Name:** Unexpected Behaviour
- **Family:** adversarial
- **Responsibility:** Model unusual but explicitly specified participant behaviour.
- **Import:** `driveai100.agents.individual.agent_043`
- **Runtime wrapper:** `driveai100.agents.individual.service_043.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
