# Agent 067 service wiring

- **Name:** Counterfactual World Model
- **Family:** world
- **Responsibility:** Compare alternative possible scene evolutions.
- **Import:** `driveai100.agents.individual.agent_067`
- **Runtime wrapper:** `driveai100.agents.individual.service_067.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
