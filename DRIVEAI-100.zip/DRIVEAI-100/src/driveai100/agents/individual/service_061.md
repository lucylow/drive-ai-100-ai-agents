# Agent 061 service wiring

- **Name:** World State Reconstruction
- **Family:** world
- **Responsibility:** Reconstruct a structured current scene.
- **Import:** `driveai100.agents.individual.agent_061`
- **Runtime wrapper:** `driveai100.agents.individual.service_061.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
