# Agent 062 service wiring

- **Name:** 3D Scene Reconstruction
- **Family:** world
- **Responsibility:** Reconstruct geometric scene representations.
- **Import:** `driveai100.agents.individual.agent_062`
- **Runtime wrapper:** `driveai100.agents.individual.service_062.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
