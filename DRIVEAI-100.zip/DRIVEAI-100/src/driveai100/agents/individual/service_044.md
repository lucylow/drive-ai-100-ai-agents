# Agent 044 service wiring

- **Name:** Sensor Degradation
- **Family:** adversarial
- **Responsibility:** Inject controlled sensor faults in simulation.
- **Import:** `driveai100.agents.individual.agent_044`
- **Runtime wrapper:** `driveai100.agents.individual.service_044.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
