# Agent 088 service wiring

- **Name:** Reproducibility
- **Family:** evaluation
- **Responsibility:** Verify experiment configuration and replayability.
- **Import:** `driveai100.agents.individual.agent_088`
- **Runtime wrapper:** `driveai100.agents.individual.service_088.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
