# Agent 015 service wiring

- **Name:** Object Tracking
- **Family:** fusion
- **Responsibility:** Maintain object identities and temporal tracks.
- **Import:** `driveai100.agents.individual.agent_015`
- **Runtime wrapper:** `driveai100.agents.individual.service_015.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
