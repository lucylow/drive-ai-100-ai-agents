# Agent 004 service wiring

- **Name:** Road Segmentation
- **Family:** perception
- **Responsibility:** Drivable areas, lane markings, road boundaries, and road topology.
- **Import:** `driveai100.agents.individual.agent_004`
- **Runtime wrapper:** `driveai100.agents.individual.service_004.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
