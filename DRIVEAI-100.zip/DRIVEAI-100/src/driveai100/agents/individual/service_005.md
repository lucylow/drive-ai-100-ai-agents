# Agent 005 service wiring

- **Name:** Traffic Signal Recognition
- **Family:** perception
- **Responsibility:** Traffic-light state, signal localization, and lane association.
- **Import:** `driveai100.agents.individual.agent_005`
- **Runtime wrapper:** `driveai100.agents.individual.service_005.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
