# Agent 052 service wiring

- **Name:** Behaviour Planning
- **Family:** planning
- **Responsibility:** Evaluate high-level manoeuvre alternatives.
- **Import:** `driveai100.agents.individual.agent_052`
- **Runtime wrapper:** `driveai100.agents.individual.service_052.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
