# Agent 023 service wiring

- **Name:** Cyclist Behaviour Prediction
- **Family:** prediction
- **Responsibility:** Model cyclist movement and nonlinear manoeuvres.
- **Import:** `driveai100.agents.individual.agent_023`
- **Runtime wrapper:** `driveai100.agents.individual.service_023.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
