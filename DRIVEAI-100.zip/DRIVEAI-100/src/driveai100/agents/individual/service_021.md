# Agent 021 service wiring

- **Name:** Vehicle Trajectory Prediction
- **Family:** prediction
- **Responsibility:** Predict future vehicle trajectories.
- **Import:** `driveai100.agents.individual.agent_021`
- **Runtime wrapper:** `driveai100.agents.individual.service_021.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
