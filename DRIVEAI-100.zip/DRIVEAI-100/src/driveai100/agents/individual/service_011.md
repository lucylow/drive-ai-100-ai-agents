# Agent 011 service wiring

- **Name:** Multi-Sensor Fusion
- **Family:** fusion
- **Responsibility:** Combine camera, LiDAR, and radar observations.
- **Import:** `driveai100.agents.individual.agent_011`
- **Runtime wrapper:** `driveai100.agents.individual.service_011.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
