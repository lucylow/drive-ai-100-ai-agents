# Agent 047 service wiring

- **Name:** Behavioural Stress
- **Family:** adversarial
- **Responsibility:** Increase interaction complexity.
- **Import:** `driveai100.agents.individual.agent_047`
- **Runtime wrapper:** `driveai100.agents.individual.service_047.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
