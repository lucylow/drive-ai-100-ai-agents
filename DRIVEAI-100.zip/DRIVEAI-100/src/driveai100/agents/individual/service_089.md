# Agent 089 service wiring

- **Name:** Statistical Analysis
- **Family:** evaluation
- **Responsibility:** Calculate uncertainty and statistical comparisons.
- **Import:** `driveai100.agents.individual.agent_089`
- **Runtime wrapper:** `driveai100.agents.individual.service_089.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
