# Agent 051 service wiring

- **Name:** Route Planning
- **Family:** planning
- **Responsibility:** Compute routes through a map graph.
- **Import:** `driveai100.agents.individual.agent_051`
- **Runtime wrapper:** `driveai100.agents.individual.service_051.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
