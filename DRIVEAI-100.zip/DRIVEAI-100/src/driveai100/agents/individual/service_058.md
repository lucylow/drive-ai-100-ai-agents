# Agent 058 service wiring

- **Name:** Parking and Low-Speed Manoeuvre
- **Family:** planning
- **Responsibility:** Study low-speed simulated manoeuvres.
- **Import:** `driveai100.agents.individual.agent_058`
- **Runtime wrapper:** `driveai100.agents.individual.service_058.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
