# Agent 035 service wiring

- **Name:** Urban Scenario
- **Family:** scenario
- **Responsibility:** Generate dense urban traffic conditions.
- **Import:** `driveai100.agents.individual.agent_035`
- **Runtime wrapper:** `driveai100.agents.individual.service_035.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
