# Agent 002 service wiring

- **Name:** LiDAR Perception
- **Family:** perception
- **Responsibility:** Point-cloud processing, 3D object detection, and geometric analysis.
- **Import:** `driveai100.agents.individual.agent_002`
- **Runtime wrapper:** `driveai100.agents.individual.service_002.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
