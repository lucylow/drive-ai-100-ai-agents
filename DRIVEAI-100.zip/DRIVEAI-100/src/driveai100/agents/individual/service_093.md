# Agent 093 service wiring

- **Name:** Experiment Design
- **Family:** research
- **Responsibility:** Design controlled experiments.
- **Import:** `driveai100.agents.individual.agent_093`
- **Runtime wrapper:** `driveai100.agents.individual.service_093.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
