# Agent 018 service wiring

- **Name:** Sensor Health
- **Family:** fusion
- **Responsibility:** Detect missing, stale, corrupted, or degraded observations.
- **Import:** `driveai100.agents.individual.agent_018`
- **Runtime wrapper:** `driveai100.agents.individual.service_018.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
