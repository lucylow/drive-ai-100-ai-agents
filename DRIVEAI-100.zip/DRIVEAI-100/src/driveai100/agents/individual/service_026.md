# Agent 026 service wiring

- **Name:** Lane Change Prediction
- **Family:** prediction
- **Responsibility:** Estimate lane-change probability and timing.
- **Import:** `driveai100.agents.individual.agent_026`
- **Runtime wrapper:** `driveai100.agents.individual.service_026.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
