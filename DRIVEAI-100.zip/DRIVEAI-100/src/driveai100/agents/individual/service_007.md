# Agent 007 service wiring

- **Name:** Pedestrian Detection
- **Family:** perception
- **Responsibility:** Pedestrian localization, pose cues, and crossing-zone observations.
- **Import:** `driveai100.agents.individual.agent_007`
- **Runtime wrapper:** `driveai100.agents.individual.service_007.Service`
- **Factory:** `build()`
- **Identity contract:** `describe()`
- **Status:** L1 research prototype; simulation only.
