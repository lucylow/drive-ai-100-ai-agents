def rasterize_points(points,resolution=.5):
 if resolution<=0: raise ValueError("resolution must be positive")
 cells={}
 for x,y in points:
  key=(int(x//resolution),int(y//resolution)); cells[key]=cells.get(key,0)+1
 return cells
def occupancy_density(cells):
 return sum(cells.values())/len(cells) if cells else 0.
