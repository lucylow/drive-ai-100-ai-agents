def compare_actor_states(previous,current):
 old={x["actor_id"]:x for x in previous}; new={x["actor_id"]:x for x in current}
 return {"added":sorted(set(new)-set(old)),"removed":sorted(set(old)-set(new)),"retained":sorted(set(old)&set(new))}
