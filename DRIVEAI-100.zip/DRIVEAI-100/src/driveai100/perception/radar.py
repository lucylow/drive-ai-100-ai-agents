def radial_velocity_components(range_rate_mps,azimuth_rad):
 import math
 return {"vx":float(range_rate_mps)*math.cos(azimuth_rad),"vy":float(range_rate_mps)*math.sin(azimuth_rad)}
def reject_radar_outliers(targets,max_abs_range_rate=80.0):
 return [t for t in targets if abs(float(t.get("range_rate_mps",0)))<=max_abs_range_rate and float(t.get("range_m",0))>=0]
