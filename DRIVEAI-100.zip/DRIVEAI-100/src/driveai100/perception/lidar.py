from math import sqrt
def filter_points(points,min_range=0.5,max_range=120.0,z_min=-3.0,z_max=4.0):
 result=[]
 for p in points:
  if len(p)<3: continue
  x,y,z=map(float,p[:3]); r=sqrt(x*x+y*y+z*z)
  if min_range<=r<=max_range and z_min<=z<=z_max: result.append((x,y,z))
 return result
def voxel_downsample(points,voxel_size=.2):
 if voxel_size<=0: raise ValueError("voxel size must be positive")
 voxels={}
 for point in points:
  key=tuple(int(float(v)//voxel_size) for v in point[:3]); bucket=voxels.setdefault(key,[0.,0.,0.,0]);
  for i in range(3): bucket[i]+=float(point[i])
  bucket[3]+=1
 return [tuple(v[i]/v[3] for i in range(3)) for v in voxels.values()]
