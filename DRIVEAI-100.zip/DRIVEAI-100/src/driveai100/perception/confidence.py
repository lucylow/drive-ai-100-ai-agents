def temperature_scale(logits,temperature=1.0):
 if temperature<=0: raise ValueError("temperature must be positive")
 import math
 scaled=[float(x)/temperature for x in logits]; peak=max(scaled); exps=[math.exp(x-peak) for x in scaled]; total=sum(exps)
 return [x/total for x in exps]
def brier_score(probabilities,one_hot):
 if len(probabilities)!=len(one_hot): raise ValueError("vector lengths differ")
 return sum((float(p)-float(y))**2 for p,y in zip(probabilities,one_hot))
def confidence_summary(scores):
 scores=list(map(float,scores))
 if any(not 0<=s<=1 for s in scores): raise ValueError("scores must be [0,1]")
 return {"count":len(scores),"mean":sum(scores)/len(scores) if scores else 0.,"minimum":min(scores) if scores else None,"maximum":max(scores) if scores else None}
