def validate_image_metadata(width,height,channels,timestamp):
 if min(width,height,channels)<=0 or timestamp<0: raise ValueError("invalid image metadata")
 return {"width":width,"height":height,"channels":channels,"timestamp":timestamp}
