def class_pixel_counts(label_map):
 counts={}
 for row in label_map:
  for label in row: counts[label]=counts.get(label,0)+1
 return counts
def drivable_area_fraction(label_map,drivable_labels):
 values=[label for row in label_map for label in row]
 return sum(x in drivable_labels for x in values)/len(values) if values else 0.0
def boundary_transition_count(label_map,road_label):
 count=0
 for row in label_map:
  for i in range(1,len(row)):
   if (row[i]==road_label)!=(row[i-1]==road_label): count+=1
 return count
