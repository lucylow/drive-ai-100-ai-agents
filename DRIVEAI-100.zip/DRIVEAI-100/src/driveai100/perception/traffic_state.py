VALID_STATES={"red","yellow","green","unknown"}
def normalize_signal_state(label):
 value=str(label).lower()
 return value if value in VALID_STATES else "unknown"
def signal_is_permissive(label):
 return normalize_signal_state(label)=="green"
