def lane_width(left,right):
 if len(left)!=len(right) or not left: raise ValueError("paired boundaries required")
 return [((a[0]+b[0])/2,(a[1]+b[1])/2) for a,b in zip(left,right)]
def polyline_spacing(points):
 return [((b[0]-a[0])**2+(b[1]-a[1])**2)**.5 for a,b in zip(points,points[1:])]
