from dataclasses import dataclass
@dataclass
class BoundingBox:
 x_min:float; y_min:float; x_max:float; y_max:float
 def validate(self):
  if self.x_max<=self.x_min or self.y_max<=self.y_min: raise ValueError("degenerate bounding box")
  return self
 @property
 def area(self): return (self.x_max-self.x_min)*(self.y_max-self.y_min)
 @property
 def center(self): return ((self.x_min+self.x_max)/2,(self.y_min+self.y_max)/2)
def intersection_over_union(a,b):
 a.validate(); b.validate(); x1=max(a.x_min,b.x_min); y1=max(a.y_min,b.y_min); x2=min(a.x_max,b.x_max); y2=min(a.y_max,b.y_max)
 intersection=max(0,x2-x1)*max(0,y2-y1); union=a.area+b.area-intersection
 return intersection/union if union else 0.0
def suppress_overlaps(detections,iou_threshold=.5):
 """Greedy per-class NMS baseline; preserves score order."""
 output=[]
 for category in sorted({d["category"] for d in detections}):
  group=sorted((d for d in detections if d["category"]==category),key=lambda d:d["confidence"],reverse=True)
  while group:
   chosen=group.pop(0); output.append(chosen); box=BoundingBox(*chosen["bbox"])
   group=[d for d in group if intersection_over_union(box,BoundingBox(*d["bbox"]))<=iou_threshold]
 return output
