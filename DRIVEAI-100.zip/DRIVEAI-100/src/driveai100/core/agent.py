from abc import ABC,abstractmethod
from time import monotonic
from driveai100.core.contracts import AgentResult,TaskStatus
class BaseAgent(ABC):
 def __init__(self,manifest): self.manifest=manifest.validate(); self.executions=0; self.failures=0
 @abstractmethod
 async def process(self,task): raise NotImplementedError
 async def execute(self,task):
  task.validate(); start=monotonic(); self.executions+=1
  try:
   output=await self.process(task)
   result=AgentResult(task.task_id,self.manifest.agent_id,TaskStatus.SUCCEEDED,output=output,confidence=output.get("confidence"),evidence_ids=[e.evidence_id for e in task.evidence],started_at=start,latency_ms=(monotonic()-start)*1000,trace_id=task.trace_id)
  except Exception as exc:
   self.failures+=1
   result=AgentResult(task.task_id,self.manifest.agent_id,TaskStatus.FAILED,error=f"{type(exc).__name__}: {exc}",warnings=["Failed output must not be consumed as valid evidence."],started_at=start,latency_ms=(monotonic()-start)*1000,trace_id=task.trace_id)
  return result.validate()
 def health(self): return {"agent_id":self.manifest.agent_id,"executions":self.executions,"failures":self.failures,"failure_rate":self.failures/self.executions if self.executions else 0.0}
