class SchemaRegistry:
 def __init__(self): self.schemas={}
 def register(self,name,version,validator):
  key=(name,version)
  if key in self.schemas: raise ValueError(f"Schema already registered: {key}")
  self.schemas[key]=validator
 def validate(self,name,version,payload):
  key=(name,version)
  if key not in self.schemas: raise KeyError(f"Unknown schema: {key}")
  return self.schemas[key](payload)
 def versions(self,name): return sorted(v for n,v in self.schemas if n==name)
