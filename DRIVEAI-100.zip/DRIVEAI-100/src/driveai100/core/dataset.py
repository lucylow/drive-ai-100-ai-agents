from dataclasses import dataclass,field
from hashlib import sha256
import json
@dataclass
class DatasetManifest:
 dataset_id:str; version:str; source:str; license:str; split:str; sample_ids:list[str]; schema_version:str="1.0"; metadata:dict=field(default_factory=dict)
 def fingerprint(self): return sha256(json.dumps(self.__dict__,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 def validate(self):
  if not self.dataset_id or not self.version or not self.source: raise ValueError("dataset identity and source required")
  if self.split not in {"train","validation","test","unassigned"}: raise ValueError("invalid split")
  if len(self.sample_ids)!=len(set(self.sample_ids)): raise ValueError("duplicate sample ids")
  return self
