from copy import deepcopy
from dataclasses import dataclass
from threading import RLock
from driveai100.errors import BlackboardConflict
@dataclass(frozen=True)
class BlackboardValue:
 key:str; value:object; version:int; writer:str
class VersionedBlackboard:
 """Thread-safe shared state with compare-and-swap version checks."""
 def __init__(self): self._values={}; self._lock=RLock()
 def read_versioned(self,key):
  with self._lock:
   item=self._values.get(key); return deepcopy(item) if item else None
 def read(self,key,default=None):
  item=self.read_versioned(key); return item.value if item else default
 def write(self,key,value,writer,expected_version=None):
  with self._lock:
   old=self._values.get(key); version=old.version if old else 0
   if expected_version is not None and version!=expected_version: raise BlackboardConflict(f"{key}: expected {expected_version}, found {version}")
   item=BlackboardValue(key,deepcopy(value),version+1,writer); self._values[key]=item; return deepcopy(item)
 def delete(self,key,expected_version=None):
  with self._lock:
   old=self._values.get(key)
   if old is None: return False
   if expected_version is not None and old.version!=expected_version: raise BlackboardConflict(key)
   del self._values[key]; return True
 def snapshot(self):
  with self._lock: return deepcopy(self._values)
