import asyncio
from driveai100.core.contracts import AgentResult,TaskStatus
class AgentRuntime:
 def __init__(self,registry,max_concurrency=12,retries=1): self.registry=registry; self.semaphore=asyncio.Semaphore(max(1,max_concurrency)); self.retries=max(0,retries); self._idempotency={}
 async def submit(self,task):
  task.validate()
  if task.idempotency_key and task.idempotency_key in self._idempotency: return self._idempotency[task.idempotency_key]
  agent=self.registry.get(task.agent_id)
  async with self.semaphore:
   last=None
   for attempt in range(self.retries+1):
    task.attempt=attempt
    try: last=await asyncio.wait_for(agent.execute(task),timeout=task.deadline_seconds)
    except asyncio.TimeoutError: last=AgentResult(task.task_id,task.agent_id,TaskStatus.TIMED_OUT,error="Agent task deadline exceeded",trace_id=task.trace_id)
    if last.status==TaskStatus.SUCCEEDED: break
    if attempt==self.retries: break
  if task.idempotency_key: self._idempotency[task.idempotency_key]=last
  return last
