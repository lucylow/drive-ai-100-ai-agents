import asyncio
from collections import defaultdict
from dataclasses import dataclass,field
from time import time
from uuid import uuid4
@dataclass(frozen=True)
class BusMessage:
 topic:str; payload:dict; message_id:str=field(default_factory=lambda:uuid4().hex); published_at:float=field(default_factory=time); idempotency_key:str|None=None
class InMemoryMessageBus:
 """Bounded async pub/sub test adapter; replace with a durable broker in production."""
 def __init__(self,max_queue_size=256): self.max_queue_size=max_queue_size; self._subscribers=defaultdict(list); self._seen=set(); self._lock=asyncio.Lock()
 async def subscribe(self,topic):
  q=asyncio.Queue(maxsize=self.max_queue_size)
  async with self._lock: self._subscribers[topic].append(q)
  return q
 async def unsubscribe(self,topic,q):
  async with self._lock:
   if q in self._subscribers[topic]: self._subscribers[topic].remove(q)
 async def publish(self,message):
  async with self._lock:
   key=message.idempotency_key
   if key and key in self._seen: return {"delivered":0,"dropped":0,"duplicate":True}
   if key: self._seen.add(key)
   subscribers=list(self._subscribers.get(message.topic,[]))
  delivered=dropped=0
  for q in subscribers:
   try: q.put_nowait(message); delivered+=1
   except asyncio.QueueFull: dropped+=1
  return {"delivered":delivered,"dropped":dropped,"duplicate":False}
