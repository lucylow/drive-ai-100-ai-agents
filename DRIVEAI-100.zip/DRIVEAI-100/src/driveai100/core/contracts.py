from dataclasses import dataclass,field,asdict
from enum import Enum
from typing import Any
from time import time
from uuid import uuid4
from driveai100.errors import ContractError
SCHEMA_VERSION="1.0"
def new_id(prefix): return f"{prefix}_{uuid4().hex}"
class TaskStatus(str,Enum):
 CREATED="created"; ACCEPTED="accepted"; RUNNING="running"; SUCCEEDED="succeeded"; PARTIAL="partial"; FAILED="failed"; REJECTED="rejected"; TIMED_OUT="timed_out"; CANCELLED="cancelled"
@dataclass(frozen=True)
class EvidenceRef:
 evidence_id:str; source:str; modality:str; timestamp:float; uri:str|None=None; checksum:str|None=None; description:str=""; metadata:dict[str,Any]=field(default_factory=dict)
@dataclass
class AgentTask:
 agent_id:str; task_type:str; scenario_id:str; payload:dict[str,Any]
 task_id:str=field(default_factory=lambda:new_id("task")); trace_id:str=field(default_factory=lambda:new_id("trace")); idempotency_key:str|None=None
 created_at:float=field(default_factory=time); deadline_seconds:float=10.0; attempt:int=0; schema_version:str=SCHEMA_VERSION
 evidence:list[EvidenceRef]=field(default_factory=list); metadata:dict[str,Any]=field(default_factory=dict)
 def validate(self):
  if not self.agent_id or not self.task_type or not self.scenario_id: raise ContractError("agent_id, task_type and scenario_id are required")
  if not isinstance(self.payload,dict): raise ContractError("payload must be a mapping")
  if self.deadline_seconds<=0 or self.attempt<0: raise ContractError("invalid deadline or attempt")
  return self
@dataclass
class AgentResult:
 task_id:str; agent_id:str; status:TaskStatus; output:dict[str,Any]=field(default_factory=dict); confidence:float|None=None
 uncertainty:dict[str,float]=field(default_factory=dict); evidence_ids:list[str]=field(default_factory=list); warnings:list[str]=field(default_factory=list)
 error:str|None=None; started_at:float|None=None; completed_at:float=field(default_factory=time); latency_ms:float|None=None; model_version:str="baseline-0.1"; schema_version:str=SCHEMA_VERSION; trace_id:str|None=None
 def validate(self):
  if self.confidence is not None and not 0<=self.confidence<=1: raise ContractError("confidence must be [0,1]")
  if self.status==TaskStatus.SUCCEEDED and self.error: raise ContractError("successful result cannot carry error")
  return self
@dataclass(frozen=True)
class AgentManifest:
 agent_id:str; name:str; division:str; responsibility:str; handler_family:str; execution_mode:str="algorithmic"; maturity_level:str="L1-prototyped"; version:str="0.1.0"
 def validate(self):
  if len(self.agent_id)!=3 or not self.agent_id.isdigit(): raise ContractError("agent id must be three digits")
  if not self.name.strip() or not self.responsibility.strip(): raise ContractError("name and responsibility required")
  return self
def to_primitive(value):
 if hasattr(value,"__dataclass_fields__"): return asdict(value)
 if isinstance(value,Enum): return value.value
 return value
