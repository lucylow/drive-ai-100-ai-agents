from collections import Counter
REQUIRED=("sample_id","timestamp","scenario_id","objects","sensor_metadata")
def analyze_dataset(records):
 counts=Counter(); missing=Counter(); seen=set(); duplicates=0; timestamp_errors=0
 for r in records:
  for key in REQUIRED:
   if key not in r or r[key] is None: missing[key]+=1
  sid=r.get("sample_id")
  if sid in seen: duplicates+=1
  seen.add(sid)
  if not isinstance(r.get("timestamp"),(int,float)): timestamp_errors+=1
  for obj in r.get("objects",[]): counts[obj.get("category","unknown")]+=1
 warnings=[]
 if duplicates: warnings.append("duplicate_sample_ids")
 if timestamp_errors: warnings.append("invalid_timestamps")
 if missing: warnings.append("missing_required_fields")
 if not records: warnings.append("empty_dataset")
 return {"sample_count":len(records),"class_counts":dict(counts),"missing_fields":dict(missing),"duplicate_ids":duplicates,"timestamp_errors":timestamp_errors,"warnings":warnings}
