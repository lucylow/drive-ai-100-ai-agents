from pathlib import Path
import hashlib,json
from time import time
class ModelRegistry:
 def __init__(self,root="artifacts/models"):
  self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
 @staticmethod
 def checksum(path):
  digest=hashlib.sha256()
  with open(path,"rb") as f:
   for chunk in iter(lambda:f.read(1024*1024),b""): digest.update(chunk)
  return digest.hexdigest()
 def register(self,model_id,version,artifact_path,dataset_version,metrics,training_run_id):
  artifact=Path(artifact_path)
  if not artifact.is_file(): raise FileNotFoundError(artifact)
  record={"model_id":model_id,"version":version,"artifact_path":str(artifact.resolve()),"dataset_version":dataset_version,"metrics":metrics,"training_run_id":training_run_id,"checksum_sha256":self.checksum(artifact),"registered_at":time()}
  out=self.root/f"{model_id}-{version}.json"; out.write_text(json.dumps(record,indent=2),encoding="utf-8"); return record
