from dataclasses import dataclass
from time import time
@dataclass
class DeadLetter:
 task_id:str; agent_id:str; reason:str; payload_summary:str; created_at:float; attempts:int
class DeadLetterQueue:
 def __init__(self,max_items=1000): self.max_items=max_items; self.items=[]
 def add(self,task,reason):
  if len(self.items)>=self.max_items: self.items.pop(0)
  item=DeadLetter(task.task_id,task.agent_id,reason,repr(task.payload)[:500],time(),task.attempt+1); self.items.append(item); return item
 def list(self): return list(self.items)
