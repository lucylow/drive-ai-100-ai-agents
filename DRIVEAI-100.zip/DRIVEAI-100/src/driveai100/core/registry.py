from driveai100.errors import AgentNotFound,DuplicateAgent
class AgentRegistry:
 def __init__(self): self._agents={}
 def register(self,agent):
  manifest=agent.manifest.validate()
  if manifest.agent_id in self._agents: raise DuplicateAgent(manifest.agent_id)
  self._agents[manifest.agent_id]=agent
 def get(self,agent_id):
  try: return self._agents[agent_id]
  except KeyError as exc: raise AgentNotFound(agent_id) from exc
 def manifests(self): return [x.manifest for x in self._agents.values()]
 def by_division(self,division): return [x for x in self._agents.values() if x.manifest.division==division]
 def __len__(self): return len(self._agents)
 def __contains__(self,agent_id): return agent_id in self._agents
