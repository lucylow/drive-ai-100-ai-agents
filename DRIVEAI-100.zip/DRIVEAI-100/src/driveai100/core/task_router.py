class TaskRouter:
 """Maps task IDs to addressable agent implementations and division families."""
 def __init__(self,registry): self.registry=registry
 def route(self,task):
  agent=self.registry.get(task.agent_id)
  return {"agent":agent,"division":agent.manifest.division,"handler_family":agent.manifest.handler_family,"task_type":task.task_type}
 def route_many(self,tasks): return [self.route(task) for task in tasks]
