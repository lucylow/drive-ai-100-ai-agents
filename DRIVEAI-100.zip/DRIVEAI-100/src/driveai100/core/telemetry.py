from collections import defaultdict
from threading import Lock
from time import perf_counter
class Telemetry:
 def __init__(self): self.counters=defaultdict(int); self.samples=defaultdict(list); self.lock=Lock()
 def increment(self,name,amount=1):
  with self.lock: self.counters[name]+=amount
 def observe(self,name,value):
  with self.lock: self.samples[name].append(float(value))
 def snapshot(self):
  with self.lock:
   return {"counters":dict(self.counters),"observations":{k:{"count":len(v),"mean":sum(v)/len(v) if v else 0,"max":max(v) if v else 0} for k,v in self.samples.items()}}
 def timer(self,name): return Timer(self,name)
class Timer:
 def __init__(self,telemetry,name): self.telemetry=telemetry; self.name=name
 def __enter__(self): self.start=perf_counter(); return self
 def __exit__(self,*args): self.telemetry.observe(self.name,(perf_counter()-self.start)*1000)
