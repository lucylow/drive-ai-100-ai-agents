import json,sqlite3
from dataclasses import asdict,is_dataclass
from enum import Enum
from pathlib import Path
class SQLiteRunStore:
 """Durable local store for experiment metadata and agent outputs."""
 def __init__(self,path="driveai.db"):
  self.path=str(path); parent=Path(self.path).parent
  if str(parent)!=".": parent.mkdir(parents=True,exist_ok=True)
  self.initialize()
 def connect(self):
  db=sqlite3.connect(self.path,timeout=10); db.execute("PRAGMA journal_mode=WAL"); return db
 def initialize(self):
  with self.connect() as db:
   db.execute("CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY,created_at REAL,status TEXT,manifest_json TEXT)")
   db.execute("CREATE TABLE IF NOT EXISTS agent_results(result_id TEXT PRIMARY KEY,run_id TEXT,agent_id TEXT,status TEXT,created_at REAL,result_json TEXT)")
   db.execute("CREATE INDEX IF NOT EXISTS idx_results_run ON agent_results(run_id)")
 @staticmethod
 def encode(value):
  def default(obj):
   if is_dataclass(obj): return asdict(obj)
   if isinstance(obj,Enum): return obj.value
   return repr(obj)
  return json.dumps(value,default=default,sort_keys=True)
 def create_run(self,run_id,created_at,manifest):
  with self.connect() as db: db.execute("INSERT INTO runs VALUES(?,?,?,?)",(run_id,created_at,"running",self.encode(manifest)))
 def finish_run(self,run_id,status):
  with self.connect() as db: db.execute("UPDATE runs SET status=? WHERE run_id=?",(status,run_id))
 def save_result(self,result_id,run_id,agent_id,status,created_at,result):
  with self.connect() as db: db.execute("INSERT OR REPLACE INTO agent_results VALUES(?,?,?,?,?,?)",(result_id,run_id,agent_id,status,created_at,self.encode(result)))
 def results_for_run(self,run_id):
  with self.connect() as db: rows=db.execute("SELECT result_json FROM agent_results WHERE run_id=? ORDER BY created_at",(run_id,)).fetchall()
  return [json.loads(row[0]) for row in rows]
