from dataclasses import dataclass
from driveai100.errors import TaskRejected
@dataclass(frozen=True)
class RuntimePolicy:
 allowed_modes:tuple=("algorithmic","neural","hybrid","llm")
 blocked_task_types:tuple=("real_vehicle_actuation","send_vehicle_command","steer_physical_vehicle")
 max_deadline_seconds:float=120.0
 def validate_task(self,task,manifest):
  if task.task_type in self.blocked_task_types: raise TaskRejected("Physical vehicle commands are unsupported")
  if task.deadline_seconds>self.max_deadline_seconds: raise TaskRejected("Deadline exceeds policy maximum")
  if manifest.execution_mode not in self.allowed_modes: raise TaskRejected("Agent mode not permitted")
  return True
