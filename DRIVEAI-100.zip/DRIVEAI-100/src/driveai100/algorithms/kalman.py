"""Inspectable 2D constant-velocity Kalman filter; state [x,y,vx,vy]."""
from math import isfinite
class ConstantVelocityKalman2D:
 def __init__(self,dt=.1,process_noise=1.0,measurement_noise=2.0):
  if dt<=0 or process_noise<0 or measurement_noise<=0: raise ValueError("invalid filter configuration")
  self.dt=dt; self.q=process_noise; self.r=measurement_noise; self.state=[0.,0.,0.,0.]
  self.p=[[10. if i==j else 0. for j in range(4)] for i in range(4)]; self.initialized=False
 def initialize(self,x,y): self.state=[float(x),float(y),0.,0.]; self.initialized=True; return self.state[:]
 def predict(self):
  if not self.initialized: raise RuntimeError("initialize before predict")
  dt=self.dt; x,y,vx,vy=self.state; self.state=[x+vx*dt,y+vy*dt,vx,vy]
  f=[[1,0,dt,0],[0,1,0,dt],[0,0,1,0],[0,0,0,1]]
  fp=[[sum(f[i][k]*self.p[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
  self.p=[[sum(fp[i][k]*f[j][k] for k in range(4))+(self.q if i==j else 0) for j in range(4)] for i in range(4)]
  return self.state[:]
 def update(self,x,y):
  if not self.initialized: return self.initialize(x,y)
  z=[float(x),float(y)]; innovation=[z[0]-self.state[0],z[1]-self.state[1]]
  s00=self.p[0][0]+self.r; s01=self.p[0][1]; s10=self.p[1][0]; s11=self.p[1][1]+self.r; det=s00*s11-s01*s10
  if abs(det)<1e-12: raise ArithmeticError("singular covariance")
  inv=[[s11/det,-s01/det],[-s10/det,s00/det]]
  pht=[[self.p[i][0],self.p[i][1]] for i in range(4)]
  k=[[pht[i][0]*inv[0][j]+pht[i][1]*inv[1][j] for j in range(2)] for i in range(4)]
  self.state=[self.state[i]+k[i][0]*innovation[0]+k[i][1]*innovation[1] for i in range(4)]
  a=[[(1. if i==j else 0.)-(k[i][j] if j<2 else 0.) for j in range(4)] for i in range(4)]
  ap=[[sum(a[i][m]*self.p[m][j] for m in range(4)) for j in range(4)] for i in range(4)]
  self.p=[[sum(ap[i][m]*a[j][m] for m in range(4))+self.r*sum(k[i][m]*k[j][m] for m in range(2)) for j in range(4)] for i in range(4)]
  if not all(isfinite(v) for v in self.state): raise ArithmeticError("non-finite state")
  return self.state[:]
