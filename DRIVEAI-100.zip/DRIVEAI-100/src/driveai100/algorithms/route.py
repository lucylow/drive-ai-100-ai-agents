import heapq
def dijkstra(graph,start,goal):
 if start not in graph or goal not in graph: raise KeyError("start and goal must exist")
 queue=[(0.0,start,[])]; best={}
 while queue:
  cost,node,path=heapq.heappop(queue)
  if node in best and cost>=best[node]: continue
  best[node]=cost; next_path=path+[node]
  if node==goal: return {"path":next_path,"cost":cost}
  for neighbor,weight in graph.get(node,[]):
   if weight<0: raise ValueError("edge costs must be non-negative")
   heapq.heappush(queue,(cost+float(weight),neighbor,next_path))
 return {"path":[],"cost":None}
