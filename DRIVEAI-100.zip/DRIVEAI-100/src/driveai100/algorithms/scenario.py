from collections import defaultdict
def scenario_dimensions(payload):
 keys=("map_name","weather","visibility_m","traffic_density","pedestrian_density","road_friction","sensor_noise","intersection_complexity")
 return {k:payload[k] for k in keys if k in payload}
def coverage_report(scenarios,dimensions=None):
 dimensions=dimensions or ["weather","map_name","traffic_density","visibility_band"]; buckets=defaultdict(set)
 for s in scenarios:
  for d in dimensions:
   value=s.get(d)
   if d=="traffic_density" and value is not None: value="low" if value<.33 else "medium" if value<.67 else "high"
   if d=="visibility_band" and "visibility_m" in s: value="poor" if s["visibility_m"]<30 else "moderate" if s["visibility_m"]<100 else "good"
   if value is not None: buckets[d].add(str(value))
 return {"scenario_count":len(scenarios),"coverage":{k:sorted(v) for k,v in buckets.items()},"unique_values":{k:len(v) for k,v in buckets.items()}}
