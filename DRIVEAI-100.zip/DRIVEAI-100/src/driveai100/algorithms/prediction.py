from math import ceil,sqrt
def constant_velocity_forecast(actor,horizon_seconds=3.0,step_seconds=.2):
 if horizon_seconds<=0 or step_seconds<=0: raise ValueError("horizon and step must be positive")
 x,y=float(actor.get("x",0)),float(actor.get("y",0)); vx,vy=float(actor.get("vx",0)),float(actor.get("vy",0))
 return [{"t":min(i*step_seconds,horizon_seconds),"x":x+vx*min(i*step_seconds,horizon_seconds),"y":y+vy*min(i*step_seconds,horizon_seconds)} for i in range(1,int(ceil(horizon_seconds/step_seconds))+1)]
def trajectory_ade(predicted,target):
 if len(predicted)!=len(target) or not predicted: raise ValueError("trajectory lengths must match")
 return sum(sqrt((p["x"]-t["x"])**2+(p["y"]-t["y"])**2) for p,t in zip(predicted,target))/len(predicted)
def trajectory_fde(predicted,target):
 if len(predicted)!=len(target) or not predicted: raise ValueError("trajectory lengths must match")
 p,t=predicted[-1],target[-1]; return sqrt((p["x"]-t["x"])**2+(p["y"]-t["y"])**2)
