from math import sqrt
def greedy_association(track_positions,detection_positions,max_distance):
 candidates=[]
 for ti,t in enumerate(track_positions):
  for di,d in enumerate(detection_positions):
   if len(t)!=len(d): continue
   distance=sqrt(sum((float(a)-float(b))**2 for a,b in zip(t,d)))
   if distance<=max_distance: candidates.append((distance,ti,di))
 candidates.sort(); used_t=set(); used_d=set(); matches=[]
 for distance,ti,di in candidates:
  if ti not in used_t and di not in used_d:
   matches.append({"track_index":ti,"detection_index":di,"distance":distance}); used_t.add(ti); used_d.add(di)
 return {"matches":matches,"unmatched_tracks":[i for i in range(len(track_positions)) if i not in used_t],"unmatched_detections":[i for i in range(len(detection_positions)) if i not in used_d]}
def weighted_position_estimate(measurements):
 if not measurements: raise ValueError("measurements required")
 total=wx=wy=0.0; sx=sy=0.0
 for m in measurements:
  variance=float(m["variance"])
  if variance<=0: raise ValueError("variance must be positive")
  weight=1/variance; sx+=float(m["x"])*weight; sy+=float(m["y"])*weight; total+=weight
 return {"x":sx/total,"y":sy/total,"variance_x":1/total,"variance_y":1/total}
