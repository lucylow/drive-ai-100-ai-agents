from math import hypot
def relative_state(a,b): return (float(b.get("x",0))-float(a.get("x",0)),float(b.get("y",0))-float(a.get("y",0)),float(b.get("vx",0))-float(a.get("vx",0)),float(b.get("vy",0))-float(a.get("vy",0)))
def time_to_collision(a,b,radius_m=0.0):
 """Closest-approach TTC for point-like constant-velocity actors; screening only."""
 rx,ry,rvx,rvy=relative_state(a,b); vv=rvx*rvx+rvy*rvy
 if vv<1e-12: return None
 t=-(rx*rvx+ry*rvy)/vv
 if t<0: return None
 miss=hypot(rx+rvx*t,ry+rvy*t)
 return t if miss<=radius_m else None
def minimum_separation(actors):
 if len(actors)<2: return None
 return min(hypot(float(a.get("x",0))-float(b.get("x",0)),float(a.get("y",0))-float(b.get("y",0))) for i,a in enumerate(actors) for b in actors[i+1:])
def pairwise_separations(actors):
 return [{"first":a.get("actor_id",str(i)),"second":b.get("actor_id",str(j)),"distance_m":hypot(float(a.get("x",0))-float(b.get("x",0)),float(a.get("y",0))-float(b.get("y",0)))} for i,a in enumerate(actors) for j,b in enumerate(actors[i+1:],i+1)]
def inside_safety_envelope(distance_m,relative_speed_mps,minimum_distance_m=2.0,stopping_time_s=1.0):
 if min(distance_m,relative_speed_mps,minimum_distance_m,stopping_time_s)<0: raise ValueError("inputs must be non-negative")
 needed=minimum_distance_m+relative_speed_mps*stopping_time_s
 return {"inside":distance_m>=needed,"required_distance_m":needed,"observed_distance_m":distance_m}
