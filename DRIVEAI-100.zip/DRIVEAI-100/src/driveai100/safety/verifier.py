from dataclasses import dataclass,asdict
from driveai100.algorithms.safety import minimum_separation,pairwise_separations
@dataclass
class Check:
 check_id:str; passed:bool; severity:str; observed:object; expected:str; method:str
class IndependentVerifier:
 """Deterministic, deliberately limited research checks independent of model confidence."""
 def verify_scene(self,actors,min_separation_m=2.0):
  value=minimum_separation(actors); passed=value is None or value>=min_separation_m
  check=Check("minimum_separation",passed,"high",value,f">= {min_separation_m} m","pairwise Euclidean centre distance")
  return {"checks":[asdict(check)],"pairwise_distances":pairwise_separations(actors),"all_checks_passed":passed,"scope":"limited geometry screening"}
 def verify_trajectory(self,points,max_speed_mps,dt_seconds):
  if dt_seconds<=0: raise ValueError("dt_seconds must be positive")
  speeds=[((b[0]-a[0])**2+(b[1]-a[1])**2)**.5/dt_seconds for a,b in zip(points,points[1:])]
  peak=max(speeds,default=0.); check=Check("speed_bound",peak<=max_speed_mps,"high",peak,f"<= {max_speed_mps} m/s","finite difference")
  return {"checks":[asdict(check)],"all_checks_passed":check.passed}
