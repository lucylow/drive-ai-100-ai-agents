from dataclasses import dataclass
@dataclass(frozen=True)
class SafetyPolicy:
 minimum_separation_m:float=2.; max_prediction_uncertainty:float=.35; require_evidence:bool=True; require_independent_verification:bool=True; simulation_only:bool=True
 def validate(self):
  if self.minimum_separation_m<0 or not 0<=self.max_prediction_uncertainty<=1: raise ValueError("invalid policy thresholds")
  if not self.simulation_only or not self.require_independent_verification: raise ValueError("research safety boundaries cannot be disabled")
  return self
