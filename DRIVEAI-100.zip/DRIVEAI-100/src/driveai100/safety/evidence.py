from hashlib import sha256
import json
def evidence_digest(evidence):
 payload=json.dumps(evidence,sort_keys=True,separators=(",",":"),default=str)
 return sha256(payload.encode()).hexdigest()
