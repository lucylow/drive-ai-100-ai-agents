from dataclasses import dataclass
@dataclass
class UncertaintyAssessment:
 score:float; accepted_for_research:bool; reasons:list

def assess_uncertainty(epistemic,aleatoric,threshold=.35,missing_modalities=0):
 for name,value in (("epistemic",epistemic),("aleatoric",aleatoric)):
  if not 0<=value<=1: raise ValueError(f"{name} must be [0,1]")
 if missing_modalities<0: raise ValueError("missing modality count cannot be negative")
 score=min(1.,.6*epistemic+.4*aleatoric+.1*missing_modalities)
 reasons=[] if score<=threshold else ["uncertainty_threshold_exceeded"]
 if missing_modalities: reasons.append("missing_sensor_modalities")
 return UncertaintyAssessment(score,score<=threshold,reasons)
