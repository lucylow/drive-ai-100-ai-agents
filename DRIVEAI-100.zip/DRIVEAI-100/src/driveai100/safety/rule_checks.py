def check_speed_limit(speed_mps,limit_mps):
 return {"passed":0<=speed_mps<=limit_mps,"observed_mps":speed_mps,"limit_mps":limit_mps}
def check_stopped(stop_duration_s,required_s=1.0):
 return {"passed":stop_duration_s>=required_s,"observed_s":stop_duration_s,"required_s":required_s}
