import pytest
from driveai100.core.blackboard import VersionedBlackboard
from driveai100.errors import BlackboardConflict
def test_compare_and_swap():
 b=VersionedBlackboard(); a=b.write("scene",{"n":1},"001",0); c=b.write("scene",{"n":2},"002",1); assert (a.version,c.version)==(1,2)
 with pytest.raises(BlackboardConflict): b.write("scene",{},"003",1)
def test_reads_are_copies():
 b=VersionedBlackboard(); b.write("k",{"items":[1]},"a"); item=b.read_versioned("k"); item.value["items"].append(2); assert b.read("k")=={"items":[1]}
