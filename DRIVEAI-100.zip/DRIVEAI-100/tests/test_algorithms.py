from driveai100.algorithms.prediction import constant_velocity_forecast
from driveai100.algorithms.safety import minimum_separation,time_to_collision
from driveai100.algorithms.fusion import greedy_association,weighted_position_estimate
from driveai100.algorithms.route import dijkstra
from driveai100.algorithms.kalman import ConstantVelocityKalman2D
def test_forecast(): assert constant_velocity_forecast({"x":0,"y":0,"vx":2,"vy":0},1,.5)[-1]=={"t":1.0,"x":2.0,"y":0.0}
def test_ttc_and_separation():
 a={"x":0,"y":0,"vx":1,"vy":0}; b={"x":3,"y":0,"vx":0,"vy":0}; assert minimum_separation([a,b])==3; assert time_to_collision(a,b,0)==3

def test_association(): assert len(greedy_association([(0,0),(10,0)],[(1,0),(9,0)],3)["matches"])==2
def test_weighted_estimate(): assert weighted_position_estimate([{"x":0,"y":0,"variance":1},{"x":2,"y":2,"variance":1}])["x"]==1
def test_route(): assert dijkstra({"a":[("b",1),("c",5)],"b":[("c",1)],"c":[]},"a","c")["path"]==["a","b","c"]
def test_kalman():
 f=ConstantVelocityKalman2D(); f.initialize(0,0); f.predict(); state=f.update(1,1); assert len(state)==4 and all(abs(x)<100 for x in state)
