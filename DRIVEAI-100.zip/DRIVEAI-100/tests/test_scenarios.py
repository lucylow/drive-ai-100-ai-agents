import pytest
from driveai100.scenarios.generator import ScenarioGenerator
from driveai100.scenarios.mutator import ScenarioMutator
from driveai100.scenarios.coverage import scenario_coverage
def test_seed_reproducibility(): assert ScenarioGenerator().generate("x",seed=42)==ScenarioGenerator(9).generate("x",seed=42)
def test_mutator_bounds():
 with pytest.raises(ValueError): ScenarioMutator().mutate({"traffic_density":.3},"traffic_density",2)
def test_coverage():
 report=scenario_coverage([{"weather":"clear","traffic_density":.1},{"weather":"rain","traffic_density":.8}]); assert report["unique_values"]["weather"]==2
