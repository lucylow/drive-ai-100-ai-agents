from driveai100.evaluation.metrics import trajectory_errors,ece,bootstrap_mean_interval
from driveai100.evaluation.reproducibility import ExperimentManifest,compare_manifests
def test_trajectory_metrics():
 m=trajectory_errors([(0,0),(2,0)],[(0,0),(1,0)]); assert m["ade_m"]==.5 and m["fde_m"]==1
def test_ece(): assert 0<=ece([.8,.6],[1,0])<=1
def test_fingerprint():
 a=ExperimentManifest("e","m","d","s",42,"Town03",("x",),{}); b=ExperimentManifest("e","m","d","s",42,"Town03",("x",),{}); assert a.fingerprint()==b.fingerprint(); assert all(x["matches"] for x in compare_manifests(a,b).values())
def test_bootstrap():
 r=bootstrap_mean_interval([1,2,3],resamples=100); assert r["lower"]<=r["mean"]<=r["upper"]
