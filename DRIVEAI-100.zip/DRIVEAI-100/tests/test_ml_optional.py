import importlib.util
import pytest
def test_ml_module_is_optional():
 if importlib.util.find_spec("torch") is None:
  with pytest.raises(ImportError): importlib.import_module("driveai100.ml.models")
 else:
  module=importlib.import_module("driveai100.ml.models"); assert hasattr(module,"MultiModalTrajectoryPredictor")
