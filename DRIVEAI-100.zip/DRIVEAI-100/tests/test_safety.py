import pytest
from driveai100.safety.verifier import IndependentVerifier
from driveai100.safety.uncertainty import assess_uncertainty
from driveai100.safety.policy import SafetyPolicy
def test_verifier_detects_close_centres(): assert not IndependentVerifier().verify_scene([{"x":0,"y":0},{"x":1,"y":0}],2)["all_checks_passed"]
def test_uncertainty_gate(): assert assess_uncertainty(.1,.1).accepted_for_research and not assess_uncertainty(.9,.9).accepted_for_research
def test_safety_policy_is_simulation_only():
 with pytest.raises(ValueError): SafetyPolicy(simulation_only=False).validate()
