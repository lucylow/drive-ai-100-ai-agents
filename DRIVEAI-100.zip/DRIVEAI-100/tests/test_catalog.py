from driveai100.catalog import load_catalog,validate_catalog
from driveai100.agents.factory import build_registry
def test_catalog(): assert validate_catalog()=={"agent_count":100,"division_count":10,"validated":True}
def test_ids_and_names():
 items=load_catalog(); assert [x.agent_id for x in items]==[f"{i:03d}" for i in range(1,101)]; assert len({x.name for x in items})==100
def test_registry():
 registry=build_registry(); assert len(registry)==100; assert registry.get("001").manifest.name=="Vision Perception"; assert registry.get("100").manifest.name=="Chief Research Intelligence"
