from driveai100.integrations.ros2_contract import validate_topic_contract,TOPICS
from driveai100.integrations.carla import CarlaReadOnlyAdapter
def test_ros_topics_unique(): assert validate_topic_contract()["valid"] and len(TOPICS)==10
def test_carla_adapter_is_lazy(): assert CarlaReadOnlyAdapter().client is None
