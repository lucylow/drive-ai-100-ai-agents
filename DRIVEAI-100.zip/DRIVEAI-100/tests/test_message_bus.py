import pytest
from driveai100.core.message_bus import InMemoryMessageBus,BusMessage
@pytest.mark.asyncio
async def test_publish_and_deduplicate():
 bus=InMemoryMessageBus(); q=await bus.subscribe("agent.result"); msg=BusMessage("agent.result",{"ok":True},idempotency_key="id1"); a=await bus.publish(msg); b=await bus.publish(msg); assert a["delivered"]==1 and b["duplicate"] is True; assert (await q.get()).payload["ok"]
