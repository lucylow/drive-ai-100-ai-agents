import pytest
from driveai100.core.contracts import AgentTask,AgentResult,TaskStatus
from driveai100.errors import ContractError
def test_task_validates(): assert AgentTask("001","perception","s1",{}).validate()
def test_deadline_positive():
 with pytest.raises(ContractError): AgentTask("001","x","s",{},deadline_seconds=0).validate()
def test_success_cannot_carry_error():
 with pytest.raises(ContractError): AgentResult("t","001",TaskStatus.SUCCEEDED,error="bad").validate()
