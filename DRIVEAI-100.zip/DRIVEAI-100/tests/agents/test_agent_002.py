import pytest
from driveai100.agents.individual.agent_002 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_002():
 agent=build(); item=describe()
 assert item["agent_id"]=="002" and item["name"]=='LiDAR Perception'
 assert agent.manifest.responsibility=='Point-cloud processing, 3D object detection, and geometric analysis.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_002_fails_closed():
 agent=build(); task=AgentTask("002","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="002" and result.error
