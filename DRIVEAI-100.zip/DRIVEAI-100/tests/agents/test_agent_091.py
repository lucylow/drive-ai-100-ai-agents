import pytest
from driveai100.agents.individual.agent_091 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_091():
 agent=build(); item=describe()
 assert item["agent_id"]=="091" and item["name"]=='Research Literature'
 assert agent.manifest.responsibility=='Organize relevant research references.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_091_fails_closed():
 agent=build(); task=AgentTask("091","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="091" and result.error
