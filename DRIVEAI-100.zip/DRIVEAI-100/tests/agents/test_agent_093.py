import pytest
from driveai100.agents.individual.agent_093 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_093():
 agent=build(); item=describe()
 assert item["agent_id"]=="093" and item["name"]=='Experiment Design'
 assert agent.manifest.responsibility=='Design controlled experiments.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_093_fails_closed():
 agent=build(); task=AgentTask("093","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="093" and result.error
