import pytest
from driveai100.agents.individual.agent_074 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_074():
 agent=build(); item=describe()
 assert item["agent_id"]=="074" and item["name"]=='Rule Compliance'
 assert agent.manifest.responsibility=='Evaluate encoded simulation traffic rules.' and agent.manifest.handler_family=="safety"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_074_fails_closed():
 agent=build(); task=AgentTask("074","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="074" and result.error
