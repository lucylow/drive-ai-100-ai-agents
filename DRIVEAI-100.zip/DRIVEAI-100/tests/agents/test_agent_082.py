import pytest
from driveai100.agents.individual.agent_082 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_082():
 agent=build(); item=describe()
 assert item["agent_id"]=="082" and item["name"]=='Perception Benchmark'
 assert agent.manifest.responsibility=='Evaluate perception performance.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_082_fails_closed():
 agent=build(); task=AgentTask("082","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="082" and result.error
