import pytest
from driveai100.agents.individual.agent_094 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_094():
 agent=build(); item=describe()
 assert item["agent_id"]=="094" and item["name"]=='Ablation Study'
 assert agent.manifest.responsibility=='Identify the contribution of individual components.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_094_fails_closed():
 agent=build(); task=AgentTask("094","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="094" and result.error
