import pytest
from driveai100.agents.individual.agent_067 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_067():
 agent=build(); item=describe()
 assert item["agent_id"]=="067" and item["name"]=='Counterfactual World Model'
 assert agent.manifest.responsibility=='Compare alternative possible scene evolutions.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_067_fails_closed():
 agent=build(); task=AgentTask("067","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="067" and result.error
