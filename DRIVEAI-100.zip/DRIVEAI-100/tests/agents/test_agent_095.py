import pytest
from driveai100.agents.individual.agent_095 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_095():
 agent=build(); item=describe()
 assert item["agent_id"]=="095" and item["name"]=='Dataset Intelligence'
 assert agent.manifest.responsibility=='Analyze dataset quality, balance, and provenance.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_095_fails_closed():
 agent=build(); task=AgentTask("095","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="095" and result.error
