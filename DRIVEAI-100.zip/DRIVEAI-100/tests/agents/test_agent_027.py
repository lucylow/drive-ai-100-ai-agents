import pytest
from driveai100.agents.individual.agent_027 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_027():
 agent=build(); item=describe()
 assert item["agent_id"]=="027" and item["name"]=='Driver Intent Prediction'
 assert agent.manifest.responsibility=='Infer possible manoeuvre intentions from observed behaviour.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_027_fails_closed():
 agent=build(); task=AgentTask("027","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="027" and result.error
