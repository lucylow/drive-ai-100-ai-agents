import pytest
from driveai100.agents.individual.agent_098 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_098():
 agent=build(); item=describe()
 assert item["agent_id"]=="098" and item["name"]=='University Collaboration'
 assert agent.manifest.responsibility=='Organize collaboration opportunities and research packages.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_098_fails_closed():
 agent=build(); task=AgentTask("098","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="098" and result.error
