import pytest
from driveai100.agents.individual.agent_009 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_009():
 agent=build(); item=describe()
 assert item["agent_id"]=="009" and item["name"]=='Weather Perception'
 assert agent.manifest.responsibility=='Visibility, precipitation, fog, glare, and environmental degradation.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_009_fails_closed():
 agent=build(); task=AgentTask("009","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="009" and result.error
