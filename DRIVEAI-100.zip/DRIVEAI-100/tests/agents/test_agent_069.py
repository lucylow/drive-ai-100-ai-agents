import pytest
from driveai100.agents.individual.agent_069 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_069():
 agent=build(); item=describe()
 assert item["agent_id"]=="069" and item["name"]=='Environmental Context'
 assert agent.manifest.responsibility=='Represent contextual conditions affecting interpretation.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_069_fails_closed():
 agent=build(); task=AgentTask("069","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="069" and result.error
