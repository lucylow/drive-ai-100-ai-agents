import pytest
from driveai100.agents.individual.agent_019 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_019():
 agent=build(); item=describe()
 assert item["agent_id"]=="019" and item["name"]=='Uncertainty Propagation'
 assert agent.manifest.responsibility=='Track uncertainty through transformations and fusion.' and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_019_fails_closed():
 agent=build(); task=AgentTask("019","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="019" and result.error
