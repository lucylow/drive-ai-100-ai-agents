import pytest
from driveai100.agents.individual.agent_100 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_100():
 agent=build(); item=describe()
 assert item["agent_id"]=="100" and item["name"]=='Chief Research Intelligence'
 assert agent.manifest.responsibility=='Coordinate research priorities and summarize validated findings.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_100_fails_closed():
 agent=build(); task=AgentTask("100","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="100" and result.error
