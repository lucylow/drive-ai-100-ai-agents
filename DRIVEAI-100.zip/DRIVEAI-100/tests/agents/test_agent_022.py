import pytest
from driveai100.agents.individual.agent_022 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_022():
 agent=build(); item=describe()
 assert item["agent_id"]=="022" and item["name"]=='Pedestrian Behaviour Prediction'
 assert agent.manifest.responsibility=='Estimate pedestrian movement and crossing hypotheses.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_022_fails_closed():
 agent=build(); task=AgentTask("022","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="022" and result.error
