import pytest
from driveai100.agents.individual.agent_043 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_043():
 agent=build(); item=describe()
 assert item["agent_id"]=="043" and item["name"]=='Unexpected Behaviour'
 assert agent.manifest.responsibility=='Model unusual but explicitly specified participant behaviour.' and agent.manifest.handler_family=="adversarial"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_043_fails_closed():
 agent=build(); task=AgentTask("043","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="043" and result.error
