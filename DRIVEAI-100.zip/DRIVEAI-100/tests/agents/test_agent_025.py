import pytest
from driveai100.agents.individual.agent_025 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_025():
 agent=build(); item=describe()
 assert item["agent_id"]=="025" and item["name"]=='Intersection Behaviour'
 assert agent.manifest.responsibility=='Model interactions at intersections.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_025_fails_closed():
 agent=build(); task=AgentTask("025","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="025" and result.error
