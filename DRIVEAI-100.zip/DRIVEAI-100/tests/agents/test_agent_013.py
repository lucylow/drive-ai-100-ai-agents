import pytest
from driveai100.agents.individual.agent_013 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_013():
 agent=build(); item=describe()
 assert item["agent_id"]=="013" and item["name"]=='Radar-LiDAR Fusion'
 assert agent.manifest.responsibility=='Combine geometric and velocity measurements.' and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_013_fails_closed():
 agent=build(); task=AgentTask("013","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="013" and result.error
