import pytest
from driveai100.agents.individual.agent_064 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_064():
 agent=build(); item=describe()
 assert item["agent_id"]=="064" and item["name"]=='Static Infrastructure Model'
 assert agent.manifest.responsibility=='Represent roads, curbs, signs, and fixed infrastructure.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_064_fails_closed():
 agent=build(); task=AgentTask("064","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="064" and result.error
