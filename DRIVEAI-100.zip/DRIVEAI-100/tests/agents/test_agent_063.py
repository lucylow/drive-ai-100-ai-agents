import pytest
from driveai100.agents.individual.agent_063 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_063():
 agent=build(); item=describe()
 assert item["agent_id"]=="063" and item["name"]=='Dynamic World Model'
 assert agent.manifest.responsibility=='Track changing objects and scene state.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_063_fails_closed():
 agent=build(); task=AgentTask("063","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="063" and result.error
