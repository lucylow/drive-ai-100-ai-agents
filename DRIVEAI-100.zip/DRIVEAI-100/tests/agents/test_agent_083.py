import pytest
from driveai100.agents.individual.agent_083 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_083():
 agent=build(); item=describe()
 assert item["agent_id"]=="083" and item["name"]=='Prediction Benchmark'
 assert agent.manifest.responsibility=='Evaluate trajectory prediction.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_083_fails_closed():
 agent=build(); task=AgentTask("083","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="083" and result.error
