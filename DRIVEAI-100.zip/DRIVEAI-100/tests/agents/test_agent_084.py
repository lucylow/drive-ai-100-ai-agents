import pytest
from driveai100.agents.individual.agent_084 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_084():
 agent=build(); item=describe()
 assert item["agent_id"]=="084" and item["name"]=='Planning Benchmark'
 assert agent.manifest.responsibility=='Evaluate candidate planning outputs.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_084_fails_closed():
 agent=build(); task=AgentTask("084","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="084" and result.error
