import pytest
from driveai100.agents.individual.agent_058 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_058():
 agent=build(); item=describe()
 assert item["agent_id"]=="058" and item["name"]=='Parking and Low-Speed Manoeuvre'
 assert agent.manifest.responsibility=='Study low-speed simulated manoeuvres.' and agent.manifest.handler_family=="planning"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_058_fails_closed():
 agent=build(); task=AgentTask("058","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="058" and result.error
