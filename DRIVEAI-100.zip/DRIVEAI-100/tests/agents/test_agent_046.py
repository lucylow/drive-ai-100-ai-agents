import pytest
from driveai100.agents.individual.agent_046 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_046():
 agent=build(); item=describe()
 assert item["agent_id"]=="046" and item["name"]=='Boundary Condition'
 assert agent.manifest.responsibility=='Test defined operational-domain boundaries.' and agent.manifest.handler_family=="adversarial"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_046_fails_closed():
 agent=build(); task=AgentTask("046","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="046" and result.error
