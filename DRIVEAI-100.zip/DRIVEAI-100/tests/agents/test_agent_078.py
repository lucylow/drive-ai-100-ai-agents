import pytest
from driveai100.agents.individual.agent_078 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_078():
 agent=build(); item=describe()
 assert item["agent_id"]=="078" and item["name"]=='Safety Evidence'
 assert agent.manifest.responsibility=='Organize evidence supporting evaluation findings.' and agent.manifest.handler_family=="safety"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_078_fails_closed():
 agent=build(); task=AgentTask("078","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="078" and result.error
