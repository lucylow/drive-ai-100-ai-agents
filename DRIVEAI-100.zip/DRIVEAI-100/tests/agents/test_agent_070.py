import pytest
from driveai100.agents.individual.agent_070 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_070():
 agent=build(); item=describe()
 assert item["agent_id"]=="070" and item["name"]=='World Model Validation'
 assert agent.manifest.responsibility=='Compare reconstructed states against simulation ground truth.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_070_fails_closed():
 agent=build(); task=AgentTask("070","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="070" and result.error
