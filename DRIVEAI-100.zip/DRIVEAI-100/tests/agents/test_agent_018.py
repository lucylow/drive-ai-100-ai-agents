import pytest
from driveai100.agents.individual.agent_018 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_018():
 agent=build(); item=describe()
 assert item["agent_id"]=="018" and item["name"]=='Sensor Health'
 assert agent.manifest.responsibility=='Detect missing, stale, corrupted, or degraded observations.' and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_018_fails_closed():
 agent=build(); task=AgentTask("018","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="018" and result.error
