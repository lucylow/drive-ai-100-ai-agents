import pytest
from driveai100.agents.individual.agent_014 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_014():
 agent=build(); item=describe()
 assert item["agent_id"]=="014" and item["name"]=='Temporal Sensor Fusion'
 assert agent.manifest.responsibility=='Align observations across timestamps.' and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_014_fails_closed():
 agent=build(); task=AgentTask("014","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="014" and result.error
