import pytest
from driveai100.agents.individual.agent_029 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_029():
 agent=build(); item=describe()
 assert item["agent_id"]=="029" and item["name"]=='Multi-Agent Behaviour Prediction'
 assert agent.manifest.responsibility=='Model interactions between multiple traffic participants.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_029_fails_closed():
 agent=build(); task=AgentTask("029","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="029" and result.error
