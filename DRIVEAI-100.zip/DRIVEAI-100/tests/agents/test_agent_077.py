import pytest
from driveai100.agents.individual.agent_077 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_077():
 agent=build(); item=describe()
 assert item["agent_id"]=="077" and item["name"]=='Failure Analysis'
 assert agent.manifest.responsibility=='Classify and reconstruct failure events.' and agent.manifest.handler_family=="safety"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_077_fails_closed():
 agent=build(); task=AgentTask("077","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="077" and result.error
