import pytest
from driveai100.agents.individual.agent_001 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_001():
 agent=build(); item=describe()
 assert item["agent_id"]=="001" and item["name"]=='Vision Perception'
 assert agent.manifest.responsibility=='Image-based object detection, classification, and localization.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_001_fails_closed():
 agent=build(); task=AgentTask("001","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="001" and result.error
