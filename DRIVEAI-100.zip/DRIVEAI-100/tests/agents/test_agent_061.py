import pytest
from driveai100.agents.individual.agent_061 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_061():
 agent=build(); item=describe()
 assert item["agent_id"]=="061" and item["name"]=='World State Reconstruction'
 assert agent.manifest.responsibility=='Reconstruct a structured current scene.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_061_fails_closed():
 agent=build(); task=AgentTask("061","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="061" and result.error
