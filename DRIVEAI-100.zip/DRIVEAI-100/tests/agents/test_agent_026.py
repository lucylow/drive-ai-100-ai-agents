import pytest
from driveai100.agents.individual.agent_026 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_026():
 agent=build(); item=describe()
 assert item["agent_id"]=="026" and item["name"]=='Lane Change Prediction'
 assert agent.manifest.responsibility=='Estimate lane-change probability and timing.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_026_fails_closed():
 agent=build(); task=AgentTask("026","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="026" and result.error
