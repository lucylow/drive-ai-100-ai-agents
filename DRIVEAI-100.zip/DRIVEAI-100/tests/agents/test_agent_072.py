import pytest
from driveai100.agents.individual.agent_072 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_072():
 agent=build(); item=describe()
 assert item["agent_id"]=="072" and item["name"]=='Time-to-Collision'
 assert agent.manifest.responsibility=='Calculate and report TTC under explicit assumptions.' and agent.manifest.handler_family=="safety"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_072_fails_closed():
 agent=build(); task=AgentTask("072","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="072" and result.error
