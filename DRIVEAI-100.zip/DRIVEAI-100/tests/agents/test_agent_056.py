import pytest
from driveai100.agents.individual.agent_056 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_056():
 agent=build(); item=describe()
 assert item["agent_id"]=="056" and item["name"]=='Speed Planning'
 assert agent.manifest.responsibility=='Study speed profiles and constraints.' and agent.manifest.handler_family=="planning"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_056_fails_closed():
 agent=build(); task=AgentTask("056","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="056" and result.error
