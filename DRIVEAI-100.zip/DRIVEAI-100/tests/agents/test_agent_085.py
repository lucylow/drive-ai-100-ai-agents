import pytest
from driveai100.agents.individual.agent_085 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_085():
 agent=build(); item=describe()
 assert item["agent_id"]=="085" and item["name"]=='Safety Benchmark'
 assert agent.manifest.responsibility=='Aggregate safety-related evaluation metrics.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_085_fails_closed():
 agent=build(); task=AgentTask("085","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="085" and result.error
