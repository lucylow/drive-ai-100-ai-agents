import pytest
from driveai100.agents.individual.agent_086 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_086():
 agent=build(); item=describe()
 assert item["agent_id"]=="086" and item["name"]=='Robustness Benchmark'
 assert agent.manifest.responsibility=='Compare performance under controlled perturbations.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_086_fails_closed():
 agent=build(); task=AgentTask("086","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="086" and result.error
