import pytest
from driveai100.agents.individual.agent_062 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_062():
 agent=build(); item=describe()
 assert item["agent_id"]=="062" and item["name"]=='3D Scene Reconstruction'
 assert agent.manifest.responsibility=='Reconstruct geometric scene representations.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_062_fails_closed():
 agent=build(); task=AgentTask("062","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="062" and result.error
