import pytest
from driveai100.agents.individual.agent_011 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_011():
 agent=build(); item=describe()
 assert item["agent_id"]=="011" and item["name"]=='Multi-Sensor Fusion'
 assert agent.manifest.responsibility=='Combine camera, LiDAR, and radar observations.' and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_011_fails_closed():
 agent=build(); task=AgentTask("011","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="011" and result.error
