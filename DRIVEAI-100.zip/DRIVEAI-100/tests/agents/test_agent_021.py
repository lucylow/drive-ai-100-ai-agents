import pytest
from driveai100.agents.individual.agent_021 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_021():
 agent=build(); item=describe()
 assert item["agent_id"]=="021" and item["name"]=='Vehicle Trajectory Prediction'
 assert agent.manifest.responsibility=='Predict future vehicle trajectories.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_021_fails_closed():
 agent=build(); task=AgentTask("021","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="021" and result.error
