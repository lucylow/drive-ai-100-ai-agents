import pytest
from driveai100.agents.individual.agent_020 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_020():
 agent=build(); item=describe()
 assert item["agent_id"]=="020" and item["name"]=='Fusion Arbitration'
 assert agent.manifest.responsibility=='Resolve conflicting observations and expose unresolved ambiguity.' and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_020_fails_closed():
 agent=build(); task=AgentTask("020","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="020" and result.error
