import pytest
from driveai100.agents.individual.agent_023 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_023():
 agent=build(); item=describe()
 assert item["agent_id"]=="023" and item["name"]=='Cyclist Behaviour Prediction'
 assert agent.manifest.responsibility=='Model cyclist movement and nonlinear manoeuvres.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_023_fails_closed():
 agent=build(); task=AgentTask("023","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="023" and result.error
