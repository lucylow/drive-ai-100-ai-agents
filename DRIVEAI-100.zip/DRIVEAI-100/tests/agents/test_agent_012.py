import pytest
from driveai100.agents.individual.agent_012 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_012():
 agent=build(); item=describe()
 assert item["agent_id"]=="012" and item["name"]=='Camera-LiDAR Calibration'
 assert agent.manifest.responsibility=='Estimate and monitor extrinsic and intrinsic calibration.' and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_012_fails_closed():
 agent=build(); task=AgentTask("012","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="012" and result.error
