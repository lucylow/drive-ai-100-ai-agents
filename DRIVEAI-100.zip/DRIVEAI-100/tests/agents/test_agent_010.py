import pytest
from driveai100.agents.individual.agent_010 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_010():
 agent=build(); item=describe()
 assert item["agent_id"]=="010" and item["name"]=='Perception Confidence'
 assert agent.manifest.responsibility=='Confidence calibration, ambiguity detection, and uncertainty reporting.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_010_fails_closed():
 agent=build(); task=AgentTask("010","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="010" and result.error
