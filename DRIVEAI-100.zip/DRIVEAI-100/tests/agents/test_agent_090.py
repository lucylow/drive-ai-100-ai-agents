import pytest
from driveai100.agents.individual.agent_090 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_090():
 agent=build(); item=describe()
 assert item["agent_id"]=="090" and item["name"]=='Benchmark Reporting'
 assert agent.manifest.responsibility=='Generate structured benchmark reports.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_090_fails_closed():
 agent=build(); task=AgentTask("090","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="090" and result.error
