import pytest
from driveai100.agents.individual.agent_038 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_038():
 agent=build(); item=describe()
 assert item["agent_id"]=="038" and item["name"]=='Rare Event Discovery'
 assert agent.manifest.responsibility=='Search for unusual or low-frequency events.' and agent.manifest.handler_family=="scenario"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_038_fails_closed():
 agent=build(); task=AgentTask("038","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="038" and result.error
