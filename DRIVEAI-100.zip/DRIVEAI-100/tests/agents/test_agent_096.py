import pytest
from driveai100.agents.individual.agent_096 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_096():
 agent=build(); item=describe()
 assert item["agent_id"]=="096" and item["name"]=='Research Reproducibility'
 assert agent.manifest.responsibility=='Package experiment configurations and artifacts.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_096_fails_closed():
 agent=build(); task=AgentTask("096","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="096" and result.error
