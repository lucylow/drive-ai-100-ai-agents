import pytest
from driveai100.agents.individual.agent_080 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_080():
 agent=build(); item=describe()
 assert item["agent_id"]=="080" and item["name"]=='Safety Governance'
 assert agent.manifest.responsibility=='Enforce evaluation policies and evidence requirements.' and agent.manifest.handler_family=="safety"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_080_fails_closed():
 agent=build(); task=AgentTask("080","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="080" and result.error
