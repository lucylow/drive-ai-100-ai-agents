import pytest
from driveai100.agents.individual.agent_007 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_007():
 agent=build(); item=describe()
 assert item["agent_id"]=="007" and item["name"]=='Pedestrian Detection'
 assert agent.manifest.responsibility=='Pedestrian localization, pose cues, and crossing-zone observations.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_007_fails_closed():
 agent=build(); task=AgentTask("007","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="007" and result.error
