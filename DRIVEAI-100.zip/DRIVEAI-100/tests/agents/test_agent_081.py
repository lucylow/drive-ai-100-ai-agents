import pytest
from driveai100.agents.individual.agent_081 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_081():
 agent=build(); item=describe()
 assert item["agent_id"]=="081" and item["name"]=='Scenario Benchmark'
 assert agent.manifest.responsibility=='Evaluate scenario execution and coverage.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_081_fails_closed():
 agent=build(); task=AgentTask("081","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="081" and result.error
