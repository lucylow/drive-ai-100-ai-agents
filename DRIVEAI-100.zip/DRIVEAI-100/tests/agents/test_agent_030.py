import pytest
from driveai100.agents.individual.agent_030 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_030():
 agent=build(); item=describe()
 assert item["agent_id"]=="030" and item["name"]=='Prediction Evaluation'
 assert agent.manifest.responsibility=='Evaluate trajectory accuracy and predictive calibration.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_030_fails_closed():
 agent=build(); task=AgentTask("030","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="030" and result.error
