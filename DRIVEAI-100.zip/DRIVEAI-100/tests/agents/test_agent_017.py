import pytest
from driveai100.agents.individual.agent_017 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_017():
 agent=build(); item=describe()
 assert item["agent_id"]=="017" and item["name"]=='Ego-Motion Estimation'
 assert agent.manifest.responsibility=="Estimate the simulated vehicle's motion." and agent.manifest.handler_family=="fusion"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_017_fails_closed():
 agent=build(); task=AgentTask("017","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="017" and result.error
