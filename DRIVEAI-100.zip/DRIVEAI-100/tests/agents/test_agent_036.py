import pytest
from driveai100.agents.individual.agent_036 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_036():
 agent=build(); item=describe()
 assert item["agent_id"]=="036" and item["name"]=='Weather Scenario'
 assert agent.manifest.responsibility=='Vary precipitation, fog, lighting, and visibility.' and agent.manifest.handler_family=="scenario"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_036_fails_closed():
 agent=build(); task=AgentTask("036","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="036" and result.error
