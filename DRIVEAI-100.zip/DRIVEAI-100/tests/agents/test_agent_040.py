import pytest
from driveai100.agents.individual.agent_040 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_040():
 agent=build(); item=describe()
 assert item["agent_id"]=="040" and item["name"]=='Scenario Coverage'
 assert agent.manifest.responsibility=='Measure coverage across scenario dimensions.' and agent.manifest.handler_family=="scenario"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_040_fails_closed():
 agent=build(); task=AgentTask("040","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="040" and result.error
