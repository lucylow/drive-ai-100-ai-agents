import pytest
from driveai100.agents.individual.agent_076 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_076():
 agent=build(); item=describe()
 assert item["agent_id"]=="076" and item["name"]=='Safety Envelope'
 assert agent.manifest.responsibility=='Analyze defined spatial and temporal constraints.' and agent.manifest.handler_family=="safety"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_076_fails_closed():
 agent=build(); task=AgentTask("076","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="076" and result.error
