import pytest
from driveai100.agents.individual.agent_097 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_097():
 agent=build(); item=describe()
 assert item["agent_id"]=="097" and item["name"]=='Research Paper Assistant'
 assert agent.manifest.responsibility=='Draft evidence-grounded technical summaries.' and agent.manifest.handler_family=="research"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_097_fails_closed():
 agent=build(); task=AgentTask("097","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="097" and result.error
