import pytest
from driveai100.agents.individual.agent_035 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_035():
 agent=build(); item=describe()
 assert item["agent_id"]=="035" and item["name"]=='Urban Scenario'
 assert agent.manifest.responsibility=='Generate dense urban traffic conditions.' and agent.manifest.handler_family=="scenario"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_035_fails_closed():
 agent=build(); task=AgentTask("035","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="035" and result.error
