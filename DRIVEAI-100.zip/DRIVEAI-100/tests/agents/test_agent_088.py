import pytest
from driveai100.agents.individual.agent_088 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_088():
 agent=build(); item=describe()
 assert item["agent_id"]=="088" and item["name"]=='Reproducibility'
 assert agent.manifest.responsibility=='Verify experiment configuration and replayability.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_088_fails_closed():
 agent=build(); task=AgentTask("088","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="088" and result.error
