import pytest
from driveai100.agents.individual.agent_024 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_024():
 agent=build(); item=describe()
 assert item["agent_id"]=="024" and item["name"]=='Traffic Flow Prediction'
 assert agent.manifest.responsibility=='Estimate traffic density, flow, and congestion.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_024_fails_closed():
 agent=build(); task=AgentTask("024","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="024" and result.error
