import pytest
from driveai100.agents.individual.agent_087 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_087():
 agent=build(); item=describe()
 assert item["agent_id"]=="087" and item["name"]=='Computational Efficiency'
 assert agent.manifest.responsibility=='Measure runtime, memory, and resource usage.' and agent.manifest.handler_family=="evaluation"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_087_fails_closed():
 agent=build(); task=AgentTask("087","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="087" and result.error
