import pytest
from driveai100.agents.individual.agent_028 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_028():
 agent=build(); item=describe()
 assert item["agent_id"]=="028" and item["name"]=='Long-Horizon Prediction'
 assert agent.manifest.responsibility=='Estimate future states across longer prediction windows.' and agent.manifest.handler_family=="prediction"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_028_fails_closed():
 agent=build(); task=AgentTask("028","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="028" and result.error
