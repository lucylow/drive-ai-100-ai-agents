import pytest
from driveai100.agents.individual.agent_060 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_060():
 agent=build(); item=describe()
 assert item["agent_id"]=="060" and item["name"]=='Planning Arbitration'
 assert agent.manifest.responsibility=='Compare candidate plans against defined constraints.' and agent.manifest.handler_family=="planning"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_060_fails_closed():
 agent=build(); task=AgentTask("060","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="060" and result.error
