import pytest
from driveai100.agents.individual.agent_065 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_065():
 agent=build(); item=describe()
 assert item["agent_id"]=="065" and item["name"]=='Traffic Digital Twin'
 assert agent.manifest.responsibility=='Maintain a simulated traffic-state representation.' and agent.manifest.handler_family=="world"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_065_fails_closed():
 agent=build(); task=AgentTask("065","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="065" and result.error
