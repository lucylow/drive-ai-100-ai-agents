import pytest
from driveai100.agents.individual.agent_042 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_042():
 agent=build(); item=describe()
 assert item["agent_id"]=="042" and item["name"]=='Occlusion Challenge'
 assert agent.manifest.responsibility=='Generate controlled visibility limitations.' and agent.manifest.handler_family=="adversarial"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_042_fails_closed():
 agent=build(); task=AgentTask("042","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="042" and result.error
