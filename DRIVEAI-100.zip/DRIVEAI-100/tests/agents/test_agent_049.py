import pytest
from driveai100.agents.individual.agent_049 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_049():
 agent=build(); item=describe()
 assert item["agent_id"]=="049" and item["name"]=='Failure Reproduction'
 assert agent.manifest.responsibility=='Recreate previously recorded simulation failures.' and agent.manifest.handler_family=="adversarial"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_049_fails_closed():
 agent=build(); task=AgentTask("049","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="049" and result.error
