import pytest
from driveai100.agents.individual.agent_008 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_008():
 agent=build(); item=describe()
 assert item["agent_id"]=="008" and item["name"]=='Cyclist and Vulnerable Road User'
 assert agent.manifest.responsibility=='Cyclists, motorcycles, mobility devices, and other vulnerable road users.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_008_fails_closed():
 agent=build(); task=AgentTask("008","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="008" and result.error
