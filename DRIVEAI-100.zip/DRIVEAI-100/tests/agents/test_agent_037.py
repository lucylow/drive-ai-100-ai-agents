import pytest
from driveai100.agents.individual.agent_037 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_037():
 agent=build(); item=describe()
 assert item["agent_id"]=="037" and item["name"]=='Road Infrastructure Scenario'
 assert agent.manifest.responsibility=='Vary road geometry and infrastructure conditions.' and agent.manifest.handler_family=="scenario"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_037_fails_closed():
 agent=build(); task=AgentTask("037","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="037" and result.error
