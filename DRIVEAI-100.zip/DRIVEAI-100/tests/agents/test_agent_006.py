import pytest
from driveai100.agents.individual.agent_006 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_006():
 agent=build(); item=describe()
 assert item["agent_id"]=="006" and item["name"]=='Traffic Sign Intelligence'
 assert agent.manifest.responsibility=='Sign recognition, supplementary panels, and regulatory interpretation.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_006_fails_closed():
 agent=build(); task=AgentTask("006","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="006" and result.error
