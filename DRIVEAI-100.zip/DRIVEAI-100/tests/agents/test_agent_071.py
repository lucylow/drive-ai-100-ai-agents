import pytest
from driveai100.agents.individual.agent_071 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_071():
 agent=build(); item=describe()
 assert item["agent_id"]=="071" and item["name"]=='Safety Monitor'
 assert agent.manifest.responsibility=='Monitor defined safety-related simulation conditions.' and agent.manifest.handler_family=="safety"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_071_fails_closed():
 agent=build(); task=AgentTask("071","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="071" and result.error
