import pytest
from driveai100.agents.individual.agent_032 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_032():
 agent=build(); item=describe()
 assert item["agent_id"]=="032" and item["name"]=='Scenario Generation'
 assert agent.manifest.responsibility=='Generate parameterized simulation scenarios.' and agent.manifest.handler_family=="scenario"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_032_fails_closed():
 agent=build(); task=AgentTask("032","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="032" and result.error
