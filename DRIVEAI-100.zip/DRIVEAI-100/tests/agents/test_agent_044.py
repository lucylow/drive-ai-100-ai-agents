import pytest
from driveai100.agents.individual.agent_044 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_044():
 agent=build(); item=describe()
 assert item["agent_id"]=="044" and item["name"]=='Sensor Degradation'
 assert agent.manifest.responsibility=='Inject controlled sensor faults in simulation.' and agent.manifest.handler_family=="adversarial"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_044_fails_closed():
 agent=build(); task=AgentTask("044","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="044" and result.error
