import pytest
from driveai100.agents.individual.agent_003 import build,describe
from driveai100.core.contracts import AgentTask,TaskStatus

def test_identity_003():
 agent=build(); item=describe()
 assert item["agent_id"]=="003" and item["name"]=='Radar Intelligence'
 assert agent.manifest.responsibility=='Doppler measurements, radial velocity, and radar-object interpretation.' and agent.manifest.handler_family=="perception"
 assert item["simulation_only"] is True

@pytest.mark.asyncio
async def test_invalid_payload_003_fails_closed():
 agent=build(); task=AgentTask("003","test","test-scenario",{}); result=await agent.execute(task)
 assert result.status==TaskStatus.FAILED and result.agent_id=="003" and result.error
