import pytest

torch = pytest.importorskip("torch")
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from driveai100.advanced.perception.torch_vision import MultiTaskPerceptionModel
from driveai100.advanced.perception.torch_losses import masked_cross_entropy, soft_dice_loss
from driveai100.advanced.prediction.torch_social import SocialTrajectoryModel
from driveai100.advanced.world.latent_memory import LatentMemory
from driveai100.advanced.training.engine import TorchTrainingEngine
from driveai100.advanced.training.checkpoint import save_checkpoint, load_checkpoint
from driveai100.advanced.training.distillation import temperature_distillation


def test_multitask_perception_forward_shapes():
    model = MultiTaskPerceptionModel(semantic_classes=5, lane_classes=3, context_classes=4)
    image = torch.randn(2, 3, 64, 64)
    output = model(image)
    assert output["semantic_logits"].shape == (2, 5, 64, 64)
    assert output["lane_logits"].shape == (2, 3, 64, 64)
    assert output["context_logits"].shape == (2, 4)


def test_segmentation_losses_are_finite():
    logits = torch.randn(2, 4, 16, 16)
    target = torch.randint(0, 4, (2, 16, 16))
    assert torch.isfinite(masked_cross_entropy(logits, target))
    assert torch.isfinite(soft_dice_loss(logits, target))


def test_social_prediction_model_shapes():
    model = SocialTrajectoryModel(feature_dim=10, hidden_dim=32, modes=3, future_steps=5)
    result = model(torch.randn(2, 4, 8, 10))
    assert result["trajectories"].shape == (2, 4, 3, 5, 2)
    assert result["probabilities"].shape == (2, 4, 3)
    assert torch.allclose(result["probabilities"].sum(-1), torch.ones(2, 4), atol=1e-5)


def test_latent_memory_padded_sequence_shapes():
    model = LatentMemory(input_dim=6, hidden_dim=16)
    output, hidden = model(torch.randn(2, 5, 6), lengths=torch.tensor([5, 3]))
    assert output.shape == (2, 5, 16)
    assert hidden.shape == (1, 2, 16)


def test_training_engine_and_checkpoint_roundtrip(tmp_path):
    torch.manual_seed(1)
    x = torch.randn(32, 4)
    y = 2 * x[:, :1]
    loader = DataLoader(TensorDataset(x, y), batch_size=8)
    model = nn.Linear(4, 1)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    engine = TorchTrainingEngine(model, optimizer, nn.functional.mse_loss, device="cpu")
    history = engine.fit(loader, validation_loader=loader, epochs=2)
    assert len(history.records) == 2
    path = tmp_path / "checkpoint.pt"
    save_checkpoint(str(path), model, optimizer, epoch=2, metadata={"run": "smoke"})
    restored = nn.Linear(4, 1)
    meta = load_checkpoint(str(path), restored)
    assert meta["epoch"] == 2
    assert meta["metadata"]["run"] == "smoke"
    assert torch.allclose(model(x), restored(x))


def test_temperature_distillation_is_non_negative():
    student = torch.randn(4, 6)
    teacher = torch.randn(4, 6)
    loss = temperature_distillation(student, teacher, temperature=2.0)
    assert torch.isfinite(loss)
    assert loss.item() >= 0
