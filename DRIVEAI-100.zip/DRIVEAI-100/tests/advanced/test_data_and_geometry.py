import json
import numpy as np
import pytest
from driveai100.advanced.data.sensor_bundle import SensorPacket, SensorBundle
from driveai100.advanced.data.annotation import BoundingBox2D, ObjectAnnotation, FrameAnnotation
from driveai100.advanced.data.manifest import ManifestEntry, DatasetManifest
from driveai100.advanced.data.windowing import TemporalWindowBuilder
from driveai100.advanced.data.samplers import ClassBalancedWeights, DeterministicWeightedSampler
from driveai100.advanced.perception.geometry import box_iou, generalized_box_iou, point_in_polygon, clip_box
from driveai100.advanced.perception.postprocess import greedy_nms, class_aware_nms
from driveai100.advanced.perception.depth_projection import depth_to_points
from driveai100.advanced.perception.tracking_metrics import tracking_summary, identity_switches


def test_sensor_bundle_validation_and_queries():
    packets = (
        SensorPacket("front", "camera", 1.00, "frame-a", "f1"),
        SensorPacket("roof", "lidar", 1.02, "cloud-a", "f1"),
    )
    bundle = SensorBundle("bundle-1", 1.01, packets, 0.05).validate(("camera", "lidar"))
    assert len(bundle.by_modality("camera")) == 1
    assert bundle.timestamp_spread() == pytest.approx(0.02)


def test_sensor_bundle_rejects_out_of_sync_and_duplicate():
    bad = SensorPacket("camera", "camera", 2.0, "x", "f")
    with pytest.raises(ValueError):
        SensorBundle("b", 1.0, (bad,), 0.1).validate()
    with pytest.raises(ValueError):
        SensorBundle("b", 1.0, (bad, bad), 1.0).validate()


def test_annotation_checks_box_and_frame_dimensions():
    box = BoundingBox2D(1, 2, 10, 12, 100, 80)
    obj = ObjectAnnotation("obj-1", "vehicle", box).validate()
    frame = FrameAnnotation("sample", "seq", 1.0, 100, 80, (obj,)).validate()
    assert frame.objects[0].box.area == 90
    with pytest.raises(ValueError):
        BoundingBox2D(-1, 0, 5, 5, 10, 10).validate()
    with pytest.raises(ValueError):
        FrameAnnotation("s", "q", 1, 20, 20, (obj,)).validate()


def test_manifest_validates_sequence_grouping_and_round_trip(tmp_path):
    entries = [
        ManifestEntry("a", "a.json", "train", "seq1", 0.0),
        ManifestEntry("b", "b.json", "train", "seq1", 1.0),
        ManifestEntry("c", "c.json", "test", "seq2", 0.0),
    ]
    manifest = DatasetManifest("demo", "1", entries)
    assert manifest.validate()["samples"] == 3
    target = tmp_path / "manifest.json"
    manifest.save(target)
    loaded = DatasetManifest.load(target)
    assert loaded.validate()["splits"]["test"] == 1


def test_manifest_rejects_sequence_leakage_and_parent_path():
    entries = [
        ManifestEntry("a", "a.json", "train", "same", 0),
        ManifestEntry("b", "b.json", "test", "same", 1),
    ]
    with pytest.raises(ValueError, match="sequence leakage"):
        DatasetManifest("d", "1", entries).validate()
    with pytest.raises(ValueError, match="safe relative"):
        ManifestEntry("x", "../outside", "train", "s", 0).validate()


def test_window_builder_never_crosses_sequence_boundary():
    ids = ["a"] * 6 + ["b"] * 6
    windows = TemporalWindowBuilder(history=3, future=2, stride=1).build(ids)
    assert windows
    for window in windows:
        assert all(i >= 0 and ids[i] == window.sequence_id for i in window.input_indices)
        assert all(ids[i] == window.sequence_id for i in window.target_indices)


def test_window_builder_optional_history_padding():
    windows = TemporalWindowBuilder(4, 1, allow_short_history=True).build(["s"] * 3)
    assert windows[0].input_indices[:3] == (-1, -1, -1)
    assert windows[0].valid_mask == (False, False, False, True)


def test_class_balanced_and_deterministic_sampler():
    weights = ClassBalancedWeights(["car"] * 10 + ["pedestrian"]).sample_weights()
    assert weights[-1] > weights[0]
    sampler = DeterministicWeightedSampler([1, 2, 3], seed=7)
    first = sampler.sample(10)
    assert first == sampler.sample(10)
    sampler.set_epoch(1)
    assert first != sampler.sample(10)


def test_box_geometry_and_nms():
    assert box_iou((0, 0, 10, 10), (5, 5, 15, 15)) == pytest.approx(25 / 175)
    assert generalized_box_iou((0, 0, 10, 10), (5, 5, 15, 15)) < box_iou((0, 0, 10, 10), (5, 5, 15, 15))
    assert point_in_polygon((1, 1), [(0, 0), (5, 0), (5, 5), (0, 5)])
    assert clip_box((-1, 2, 12, 15), 10, 10) == (0.0, 2.0, 10.0, 10.0)
    assert greedy_nms([(0,0,10,10), (1,1,9,9)], [0.9, 0.8], 0.5) == [0]
    assert len(class_aware_nms([(0,0,10,10), (1,1,9,9)], [0.9, 0.8], [1, 2])) == 2


def test_depth_projection_and_tracking_summary():
    depth = np.ones((2, 2), dtype=float)
    K = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
    points = depth_to_points(depth, K)
    assert points.shape == (4, 3)
    assert tracking_summary(8, 1, 2, 1)["recall"] == pytest.approx(8/10)
    assert identity_switches([{"a": "x"}, {"a": "y"}]) == 1
