import numpy as np
import pytest
from driveai100.advanced.prediction.trajectory_metrics import ade_fde, min_ade
from driveai100.advanced.prediction.trajectory_sampling import normalize_mode_probabilities, select_top_modes, resample_trajectory
from driveai100.advanced.safety.collision_probability import estimate_collision_probability
from driveai100.advanced.safety.temporal_monitor import HysteresisMonitor
from driveai100.advanced.scenario.specification import ScenarioSpecification, ScenarioActor, ParameterRange
from driveai100.advanced.scenario.interaction_graph import InteractionGraph
from driveai100.advanced.scenario.parameter_sweep import ParameterSweep
from driveai100.advanced.scenario.coverage_report import ScenarioCoverage


def test_trajectory_metrics_and_mask():
    target = np.array([[[0.,0.], [1.,0.], [2.,0.]]])
    pred = target + 1
    result = ade_fde(pred, target, mask=np.array([[True, True, False]]))
    assert result["ade"] == pytest.approx(np.sqrt(2))
    assert result["valid_trajectories"] == 1


def test_min_ade_and_mode_selection():
    target = np.zeros((1, 2, 2))
    preds = np.stack([target + 2, target + 0.1], axis=1)
    result = min_ade(preds, target, probabilities=np.array([[0.2, 0.8]]))
    assert result["min_ade"] < 0.2
    chosen, probs, indices = select_top_modes(preds, [[0.2, 0.8]], 1)
    assert chosen.shape[1] == 1 and probs[0, 0] == pytest.approx(1.0)
    assert indices[0, 0] == 1


def test_trajectory_probability_validation_and_resampling():
    with pytest.raises(ValueError):
        normalize_mode_probabilities([[0, 0]])
    values = resample_trajectory([[0,0], [2,2]], [0,2], [0,1,2])
    assert values.tolist() == [[0,0], [1,1], [2,2]]


def test_monte_carlo_collision_probability():
    ego = np.zeros((100, 3, 2))
    actor = np.ones((100, 3, 2)) * 10
    actor[0, 1] = 0.1
    result = estimate_collision_probability(ego, actor, radius=0.5)
    assert result["probability"] == pytest.approx(0.01)
    assert result["samples"] == 100


def test_temporal_hysteresis_monitor():
    monitor = HysteresisMonitor("ttc_low", 2.0, 3.0, direction="below", minimum_duration=1.0)
    assert monitor.update(1.0, 0.0) is None
    event = monitor.update(4.0, 1.2)
    assert event is not None and event.duration_seconds == pytest.approx(1.2)
    assert monitor.active is False


def test_scenario_spec_and_interaction_graph():
    spec = ScenarioSpecification(
        "scenario-1", "Town01", "0.9.15", 42, 10.0,
        (ScenarioActor("v1", "vehicle", {"x": 0.0}, "constant_velocity"),),
        (ParameterRange("rain", 0, 1, "ratio"),),
    )
    assert "scenario-1" in spec.canonical_json()
    graph = InteractionGraph()
    graph.add_actor("v1"); graph.add_actor("p1")
    graph.add_interaction("v1", "p1", "yields_to", 0.9)
    assert len(graph.critical_pairs()) == 1
    assert graph.coverage()["yields_to"] == 1


def test_parameter_sweep_and_coverage():
    sweep = ParameterSweep({"rain": (0, 1), "density": (0, 1)}, seed=3)
    assert len(sweep.grid(3)) == 9
    assert sweep.random(4) == sweep.random(4)
    coverage = ScenarioCoverage({"weather": ("clear", "rain"), "road": ("urban", "highway")})
    coverage.record({"weather": "clear", "road": "urban"})
    report = coverage.report()
    assert report["dimensions"]["weather"]["coverage"] == 0.5
    assert report["pair_count"] == 1


def test_collision_probability_excludes_all_invalid_samples():
    ego = np.full((2, 2, 2), np.nan)
    actor = np.full((2, 2, 2), np.nan)
    result = estimate_collision_probability(ego, actor, radius=1.0)
    assert np.isnan(result["probability"])
    assert result["samples"] == 0
    assert result["excluded_invalid_samples"] == 2


def test_temporal_monitor_rejects_non_monotonic_update():
    monitor = HysteresisMonitor("event", 1.0, 0.5, direction="above")
    monitor.update(0.0, 5.0)
    with pytest.raises(ValueError, match="monotonic"):
        monitor.update(0.0, 4.0)
