import numpy as np
import pytest
from driveai100.advanced.research.active_learning import CandidateSample, ActiveLearningRanker
from driveai100.advanced.research.experiment_matrix import ExperimentMatrix
from driveai100.advanced.research.claim_registry import ClaimRegistry, ResearchClaim, ClaimStatus
from driveai100.advanced.governance.data_access import AccessRequest, AccessPolicy, DatasetAccessController
from driveai100.advanced.training.class_balanced import effective_number_weights, focal_loss
from driveai100.advanced.training.validation import MetricValidator, select_best_checkpoint
from driveai100.advanced.training.domain_adaptation import coral_distance, maximum_mean_discrepancy
from driveai100.advanced.orchestration.task_policy import AgentCapability, TaskRouter
from driveai100.advanced.orchestration.failure_recovery import FailureRecovery
from driveai100.advanced.evaluation.confusion import confusion_matrix, per_class_metrics
from driveai100.advanced.evaluation.reliability import reliability_bins
from driveai100.advanced.monitoring.model_drift import population_stability_index, drift_status
from driveai100.advanced.monitoring.inference_latency import LatencyMonitor
from driveai100.advanced.monitoring.health_registry import HealthRegistry


def test_active_learning_ranker_and_cost_budget():
    ranker = ActiveLearningRanker()
    items = [CandidateSample("easy", .1, .2, .1, 1), CandidateSample("hard", .9, .8, .8, 1)]
    assert ranker.rank(items)[0]["sample_id"] == "hard"
    assert ranker.rank(items, budget=1)["selected"][0]["sample_id"] == "hard"


def test_experiment_matrix_and_claim_evidence():
    matrix = ExperimentMatrix({"model": ("a", "b"), "seed": (1, 2)})
    assert len(matrix.build()) == 4
    registry = ClaimRegistry(); registry.add(ResearchClaim("c1", "Hypothesis statement"))
    with pytest.raises(ValueError): registry.adjudicate("c1", ClaimStatus.SUPPORTED)
    registry.attach_evidence("c1", "run-001", "Only evaluated on Town01")
    assert registry.adjudicate("c1", ClaimStatus.SUPPORTED).status == ClaimStatus.SUPPORTED


def test_dataset_access_policy():
    controller = DatasetAccessController([AccessPolicy("ds", ("benchmark",), ("image", "label"), requires_approval=True)])
    request = AccessRequest("researcher", "ds", "benchmark", ("image",))
    assert not controller.authorize(request)["allowed"]
    assert controller.authorize(request, approved=True)["allowed"]
    denied = controller.authorize(AccessRequest("u", "ds", "commercial", ("image",)), approved=True)
    assert not denied["allowed"]


def test_training_helpers_and_domain_alignment():
    weights = effective_number_weights({"car": 100, "pedestrian": 5})
    assert weights["pedestrian"] > weights["car"]
    assert focal_loss(.9, True) < focal_loss(.4, False)
    source = np.random.default_rng(1).normal(size=(20, 4))
    target = np.random.default_rng(2).normal(size=(20, 4))
    assert coral_distance(source, target)["coral_loss"] >= 0
    assert maximum_mean_discrepancy(source, target) >= -1e-8


def test_metric_validator_and_checkpoint_selection():
    validator = MetricValidator(("ade", "fde"), {"ade": (0, 100)})
    assert validator.validate({"ade": 2.0, "fde": 3.0})["valid"]
    assert not validator.validate({"ade": float("nan"), "fde": 3})["valid"]
    best = select_best_checkpoint([{"checkpoint_id":"a","ade":2}, {"checkpoint_id":"b","ade":1}], "ade")
    assert best["checkpoint_id"] == "b"


def test_router_and_failure_recovery():
    router = TaskRouter([
        AgentCapability("001", frozenset({"vision"}), frozenset({"camera"}), priority=1),
        AgentCapability("002", frozenset({"vision"}), frozenset({"camera", "lidar"}), priority=2),
    ])
    assert router.require_one("vision", ["lidar"]) == "002"
    recovery = FailureRecovery(2, 5)
    recovery.record_failure("002", "timeout", now=10)
    state = recovery.record_failure("002", "timeout", now=11)
    assert state["quarantined"]
    assert not recovery.available("002", now=12)
    assert recovery.available("002", now=17)


def test_confusion_reliability_drift_and_latency():
    cm = confusion_matrix(["car", "ped", "car"], ["car", "car", "car"], ["car", "ped"])
    assert per_class_metrics(cm)["recall"][0] == 1.0
    rel = reliability_bins([.2, .8], [0, 1], bins=2)
    assert rel["sample_count"] == 2
    psi = population_stability_index(np.arange(100), np.arange(100))
    assert psi < 1e-6
    assert drift_status(0.3)["status"] == "critical_review_required"
    monitor = LatencyMonitor(window=3, budget_ms=10)
    monitor.record(5); monitor.record(20)
    assert monitor.snapshot()["over_budget_rate"] == .5
    health = HealthRegistry(); health.report("model-a", True, timestamp=10)
    assert health.get("model-a")["status"] == "healthy"


def test_beta_zero_class_balanced_weights_are_equal():
    weights = effective_number_weights({"common": 100, "rare": 2}, beta=0)
    assert weights["common"] == pytest.approx(1.0)
    assert weights["rare"] == pytest.approx(1.0)


def test_reliability_rejects_non_finite_values():
    with pytest.raises(ValueError):
        reliability_bins([0.5, float("nan")], [1, 0])
