import pytest
from driveai100.agents.factory import build_registry
from driveai100.core.contracts import AgentTask,TaskStatus
from driveai100.core.runtime import AgentRuntime
@pytest.mark.asyncio
async def test_perception_task():
 result=await AgentRuntime(build_registry(),retries=0).submit(AgentTask("001","detect","s1",{"detections":[{"category":"car","position":[1,2],"confidence":.9}]})); assert result.status==TaskStatus.SUCCEEDED and result.output["valid_count"]==1
@pytest.mark.asyncio
async def test_missing_required_input_fails_closed():
 result=await AgentRuntime(build_registry(),retries=0).submit(AgentTask("021","predict","s1",{})); assert result.status==TaskStatus.FAILED and "actors is required" in result.error
