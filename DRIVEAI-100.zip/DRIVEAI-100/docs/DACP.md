# DRIVEAI Agent Communication Protocol (DACP)

## Envelope

`AgentTask` includes `task_id`, `trace_id`, `agent_id`, `task_type`, `scenario_id`, `payload`, `idempotency_key`, `created_at`, `deadline_seconds`, `attempt`, `schema_version`, `evidence` and `metadata`.

`AgentResult` includes task/agent IDs, status, output, confidence, uncertainty, evidence IDs, warnings, error, timestamps, latency, model version, schema version and trace ID.

## Message types

`agent.task`, `agent.accepted`, `agent.progress`, `agent.result`, `agent.error`, `agent.cancel`, `agent.heartbeat`, `agent.review.request`, `agent.review.result`, and `experiment.event`.

## Production delivery requirements

The included `InMemoryMessageBus` is a local test adapter. A production replacement should provide durable delivery, bounded retention, explicit acknowledgement, idempotency, expiry, dead-letter handling, bounded retries, authenticated publishers, consumer isolation and metrics. Messages should be treated as untrusted input even when sent by another agent.

## Evidence discipline

No result should claim a measured fact without source evidence IDs or simulator provenance. Confidence fields are not calibration guarantees. LLM-generated text must not be parsed as executable scenario instructions.
