# Agent maturity

| Level | Name | Meaning |
|---|---|---|
| L0 | Specified | Responsibility and contracts documented |
| L1 | Prototyped | Basic implementation or mock exists |
| L2 | Integrated | Connected to shared workflow |
| L3 | Evaluated | Tested against declared benchmark cases |
| L4 | Research validated | Independently reviewed and reproducible |

The catalog includes all 100 specified agent identities. Family-level baseline handlers make them addressable and testable, but they do not mean every role has a fully trained specialist neural model. Promotion must happen separately per agent.
