# Deployment notes

The default package is local Python. It does not automatically start CARLA, ROS 2, a GPU server, PostgreSQL or a web dashboard. The Docker demo runs deterministic sample tasks.

Production-scale additions to consider:

- Redis Streams, NATS or Kafka for distributed DACP events.
- PostgreSQL for experiment metadata and indexes.
- S3-compatible storage for sensor frames and model artifacts.
- MLflow for experiments and model lineage.
- Prometheus/Grafana for operations telemetry.
- Pinned CARLA server/build, map and sensor blueprint versions.
- Dedicated ROS 2 interface package and tested QoS matrix.
- Authentication, service authorization, network segmentation and secrets management.

SQLite and the in-memory bus are local development adapters, not production distributed infrastructure.
