# DRIVEAI 100 — AI Engineering Expansion, Volume 2

This volume adds research-grade engineering utilities to the original DRIVEAI 100 foundation. It is deliberately additive under `src/driveai100/advanced/` and does not replace the first volume's contracts or agent identities.

## New capability families

- **Data integrity:** synchronized sensor bundles, validated frame/object annotations, safe dataset manifests, sequence-preserving temporal windows, deterministic weighted sampling.
- **Vision:** bounding-box geometry, generalized IoU, polygon tests, class-aware NMS, calibrated depth projection, point-cloud transforms, tracking metrics.
- **Prediction:** multimodal trajectory resampling, top-mode selection, masked ADE/FDE and minADE metrics.
- **World models:** sequential latent memory and direct simulator-alignment metrics.
- **Scenario intelligence:** typed scenario specifications, actor-interaction graphs, deterministic parameter sweeps and coverage reports.
- **Safety research:** sampled collision-probability estimates with Wilson intervals and temporal hysteresis monitors.
- **Training:** long-tail class weights, focal objectives, metric validation, domain-alignment losses.
- **Research intelligence:** active-learning selection, factorial experiment matrices and claim/evidence state management.
- **Operations:** capability-based routing, agent quarantine/recovery, confusion matrices, reliability diagrams, input-drift and latency monitors, dependency health.
- **Explainability:** sliding occlusion sensitivity and optional gradient/integrated-gradient attribution.
- **Governance:** dataset field-level access policy checks.

## Install and run

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
pytest -q
python -m driveai100.cli validate-catalog
python -m driveai100.cli demo
```

Optional PyTorch functions are imported only by users who install the `ml` extra:

```bash
python -m pip install -e '.[ml]'
```

## Important semantics

The new modules are evaluation and research components. A Monte Carlo collision estimate is conditional on its supplied sample distribution. Distribution-shift scores are alarms for investigation, not proof of model failure. Model explanations are diagnostic approximations, not causal explanations. Dataset access checks implement a local policy layer and do not replace institutional/legal approvals. No module creates a real-vehicle actuator interface.
