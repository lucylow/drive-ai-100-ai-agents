# DRIVEAI 100 UI redesign plan

## Direction

**Chosen style: Graphite Mission Control.** A dark automotive-research workspace with graphite surfaces, blueprint grid texture, cyan signal lines, and restrained green/amber/red state colors.

Core principles: evidence before decoration; dense but calm information hierarchy; every status has a provenance label; navigation follows the research loop from overview to agents, simulation, and experiments.

Typography uses system UI text with a condensed display treatment for section labels. Motion is limited to short state transitions and subtle signal-pulse effects. The brand essence is a serious multi-agent autonomy laboratory for researchers who need to inspect, compare, and reproduce driving intelligence.

## Implementation

- Add a package-owned static UI under `src/driveai100/ui/`.
- Keep the existing Python agents, contracts, and workflows unchanged.
- Extend the FastAPI adapter with read-only `/demo` and `/agent-health` endpoints plus static UI serving.
- Use `/agents`, `/health`, `/catalog/validate`, `/demo`, and `/agent-health` as the UI data sources.
- Mark unavailable runtime telemetry as unavailable instead of fabricating live values.

## Project structure

- `src/driveai100/ui/index.html`: application shell and semantic page regions.
- `src/driveai100/ui/styles.css`: responsive graphite mission-control visual system.
- `src/driveai100/ui/app.js`: endpoint-backed state, agent network, simulation viewport, and research panels.
- `src/driveai100/integrations/api.py`: preserved API plus read-only UI telemetry endpoints.
