# Experiment protocol template

## Research question and hypothesis
Write one measurable question and expected direction.

## Baseline and candidate
Record code commit, model/checkpoint, data, simulator and configuration versions.

## Scenario cohort
List map IDs, scenario IDs, seeds, split and exclusion criteria.

## Primary and secondary outcomes
Predeclare metrics and report negative outcomes.

## Controls
Hold initial state, weather, sensor configuration and random seeds constant for paired comparison.

## Analysis plan
Define summary statistics, confidence interval method, missing-data handling and stopping rules.

## Safety and limitations
List simulated hazards, assumptions, independent checks and remaining blind spots.

## Results and artifacts
Attach per-scenario results, hashes, plots, failure logs and reproduction command.
