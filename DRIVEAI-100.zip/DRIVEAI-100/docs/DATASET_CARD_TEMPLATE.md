# Dataset card

- Dataset name/version:
- Owner/source/license:
- Collection or simulation method:
- Intended research uses and exclusions:
- Map/geographic and weather coverage:
- Road-user classes and annotation schema:
- Sensor modalities and calibration:
- Timestamp synchronization:
- Quality assurance and label review:
- Class balance and known gaps:
- Privacy/retention policy:
- Train/validation/test split method:
- Leakage checks:
- Provenance, version and checksums:
