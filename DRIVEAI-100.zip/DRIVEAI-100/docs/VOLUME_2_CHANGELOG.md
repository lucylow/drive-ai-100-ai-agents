# Volume 2 — Change Log

## What was added

Volume 2 extends the original DRIVEAI 100 project without changing its agent IDs or the original L1 baseline service contracts.

### Research and AI engineering additions

- New synchronization bundle and dataset manifest validation for camera, LiDAR, radar, IMU, GPS and map sensor evidence.
- Annotation contracts for 2D boxes, object labels, frame metadata and lane polylines.
- Sequence-safe temporal window construction and deterministic class-balanced sampling.
- Vision geometry, generalized box IoU, polygon containment, greedy/class-aware NMS, depth projection and tracking metrics.
- Multimodal trajectory mode selection, interpolation, masked ADE/FDE and minADE metrics.
- Latent recurrent memory for sequential world-model feature processing and simulator alignment metrics.
- Declarative scenario specifications, road-user interaction graphs, parameter sweeps and coverage accounting.
- Monte Carlo collision probability estimation with invalid-sample exclusion and a Wilson confidence interval.
- Temporal hysteresis event monitors with monotonic timestamp enforcement.
- Active-learning selection, factorial experiment matrices and evidence-linked research claim management.
- Class-balanced learning objectives, focal loss, metric validation and domain-alignment losses.
- Capability-aware agent routing and failure quarantine/recovery.
- Confusion matrix, reliability-bin, distribution-shift, latency and dependency-health monitoring.
- Occlusion sensitivity and optional PyTorch gradient attribution.
- Dataset field-level access policies.

## Verification

- All Python modules compile.
- Agent catalog validates 100 IDs across 10 divisions.
- Demo workflow completes.
- Full automated test suite: 264 passed.
- PyTorch CPU smoke tests cover the multitask perception model, social trajectory model, latent memory, training engine and checkpoint save/load.

## Scope

These additions are research utilities, evaluation tooling and simulation support. They do not certify a driving stack and do not expose physical vehicle actuation.
