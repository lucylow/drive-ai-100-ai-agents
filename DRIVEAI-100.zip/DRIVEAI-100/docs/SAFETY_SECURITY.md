# Safety and security boundaries

- Simulation/research only; no physical actuation path is provided.
- Agent consensus and LLM output cannot override independent checks.
- Model confidence is advisory unless calibrated on a representative held-out set.
- Missing, stale or degraded sensors must remain explicit in outputs.
- Scenario perturbations must be bounded and checked by the simulator.
- Research artifacts need provenance, checksums and immutable run identifiers.
- Treat scenario descriptions, retrieved documents and model outputs as untrusted data.
- Never execute instructions embedded in untrusted scenario or research text.
- Separate untrusted generated proposals from deterministic simulator configuration.
- Use least-privilege service credentials and keep secrets out of the repository.

The included verifier is a limited geometry-screening example, not a safety case, ISO compliance claim, SOTIF assessment or automotive cybersecurity certification.
