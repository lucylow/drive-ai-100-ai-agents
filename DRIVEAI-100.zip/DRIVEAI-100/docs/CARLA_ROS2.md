# CARLA and ROS 2 integration

## CARLA adapter

The optional adapter reads a CARLA world snapshot and extracts actor identifiers, positions and velocities for vehicles and walkers. Extend it with version-matched camera, LiDAR, radar, GNSS and IMU sensor blueprints. Preserve each sensor's frame ID and simulator timestamp. CARLA server and Python API must be version-matched; pin the specific build in the experiment manifest.

## ROS 2 topics

The topic contract contains:

- `/driveai/camera/front`
- `/driveai/lidar/points`
- `/driveai/radar/tracks`
- `/driveai/ego/odometry`
- `/driveai/perception/objects`
- `/driveai/fusion/tracks`
- `/driveai/prediction/trajectories`
- `/driveai/world/state`
- `/driveai/simulation/events`
- `/driveai/evaluation/findings`

QoS profiles are starting suggestions only. Test reliability, durability, history, deadline, lifespan, liveliness and matching QoS on the chosen ROS middleware. Define stable custom message schemas in a dedicated ROS 2 interface package before team-wide integration.

No physical vehicle command topic or actuator bridge exists in this repository.
