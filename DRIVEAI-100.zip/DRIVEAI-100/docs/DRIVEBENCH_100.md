# DRIVEBENCH 100 — evaluation protocol

DRIVEBENCH 100 is the project's local reproducible test framework, not an external official leaderboard.

| Area | Candidate metrics |
|---|---|
| Perception | Precision, recall, AP, localization error, calibration |
| Fusion | Association accuracy, ID continuity, position/velocity error, uncertainty propagation |
| Prediction | ADE, FDE, miss rate, NLL, calibration |
| Scenario generation | Validity, diversity, parameter coverage, replay success |
| Planning research | Candidate feasibility, progress, smoothness, defined constraint violations |
| Safety | Collision events, minimum separation, TTC indicators, off-road duration, rule violations |
| Robustness | Performance change under controlled perturbations |
| Efficiency | Latency, throughput, memory, GPU utilization |
| Reproducibility | Config fingerprints, artifact hashes, replay consistency |
| Orchestration | Completion rate, retries, failed tasks, queue wait, workflow latency |

## Experiment protocol

1. State a falsifiable hypothesis, baseline, candidate, primary metric and stopping rule.
2. Freeze code, model, dataset, simulator, map, scenario IDs, random seeds and sensor configuration.
3. Run baseline and candidate on paired initial states where possible.
4. Store per-scenario metrics, failures and evidence artifacts.
5. Report aggregate statistics and uncertainty intervals.
6. Run ablations to identify which subsystem accounts for any measured change.
7. Recompute critical safety measurements using independent logic.
8. Publish exclusions, gaps, known failure modes and limitations.

## Interpretation cautions

Centre distance is not oriented bounding-box collision geometry. TTC depends on the assumed relative-motion model and collision radius. A planner's scalar score is not a safety verdict. Results are only meaningful when coordinate frame, object extents, timestamps, sampling interval and metric definition are documented.
