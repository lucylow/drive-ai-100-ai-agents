# DRIVEAI 100 — architecture

## Design principles

1. An agent is a stable logical capability, not necessarily a separate process or LLM instance.
2. Neural inference, numerical algorithms and language-model synthesis are distinct execution types.
3. Every task carries scenario, trace, schema and deadline metadata.
4. Evidence references and model/config versions must survive the complete workflow.
5. Shared state uses version checks; a late agent cannot silently overwrite newer observations.
6. Safety verification remains independent of model confidence, agent voting and planning scores.
7. Simulation adapters are read-only in this foundation. There is no real vehicle command interface.

## System layers

```mermaid
flowchart LR
  subgraph Inputs
    C[CARLA sensors]
    D[Recorded datasets]
    S[Synthetic scenarios]
  end
  subgraph Intelligence
    P[Perception]
    F[Sensor fusion]
    T[Trajectory prediction]
    G[Scenario intelligence]
    W[World models]
    L[Planning research]
  end
  subgraph Coordination
    R[100-agent registry]
    O[Supervisor / task router]
    M[DACP message bus]
    B[(Versioned blackboard)]
  end
  subgraph Assurance
    V[Independent verifier]
    E[DRIVEBENCH 100]
    A[Audit and experiment artifacts]
  end
  C-->P; D-->P; S-->G; P-->F; F-->T; T-->W; G-->W; W-->L
  R-->O; O<-->M; O-->P; O-->F; O-->T; O-->G; O-->W; O-->L
  P-->B; F-->B; T-->B; G-->B; W-->B; L-->B; B-->V; V-->E; E-->A
```

## Task lifecycle

```mermaid
sequenceDiagram
  participant U as Workflow
  participant R as Agent Registry
  participant A as Specialist Agent
  participant B as Blackboard
  participant DB as Run Store
  U->>R: resolve agent_id
  R-->>U: manifest + implementation
  U->>A: validated AgentTask
  A->>A: validate and execute
  A-->>U: AgentResult + warnings + evidence IDs
  U->>B: compare-and-swap result write
  U->>DB: persist run artifact
```

## AI topology

- Perception converts raw camera/LiDAR/radar inputs to object, road, signal and environmental evidence.
- Sensor fusion checks coordinate transforms, timestamps, association and state uncertainty.
- Prediction builds multiple futures and interaction hypotheses from tracked temporal history.
- Scenario intelligence samples and mutates bounded parameterized simulation conditions.
- World models represent scene state and predicted transitions, then validate against simulator truth.
- Planning agents generate and compare candidate paths/behaviours for research analysis only.
- Safety agents independently recompute selected measurements from simulator state.
- Research/evaluation agents measure, audit and summarize reproducible findings.

## Maturity

All 100 agent IDs are registered. Family handlers provide first-pass deterministic behavior. Neural model architectures are optional and untrained. The current package is a foundation, not a set of 100 trained or independently validated AI systems.
