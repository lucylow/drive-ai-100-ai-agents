# Agent 074 — Rule Compliance

**Master specification responsibility:** Evaluate encoded simulation traffic rules.

## Service boundary

This role is an individually addressable identity in the registry. Its current implementation routes through the `safety` baseline family. The role is not a separately trained model and must not be presented as research-validated solely because it is registered.

## Inputs and outputs

Input includes scenario ID, family-specific typed payload, optional evidence references, timestamps and frame metadata. Output includes agent/task/scenario IDs, structured result, warnings, model/maturity metadata and evidence IDs.

## Acceptance criteria

1. Reject missing and malformed fields.
2. Preserve task, scenario and trace identifiers.
3. Preserve evidence lineage and model/config version.
4. Execute within configured deadlines and return structured failure state.
5. Pass its dedicated unit contract and an independent held-out scenario evaluation.
6. Never override independent safety checks or publish physical actuator commands.

**Maturity:** L1 prototyped foundation. Promotion requires agent-specific evidence.
