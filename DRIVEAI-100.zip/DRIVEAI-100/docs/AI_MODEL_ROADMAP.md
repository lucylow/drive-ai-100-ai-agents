# AI model development roadmap

## Perception and scene intelligence

Fine-tune driving-domain object detection and semantic segmentation. Add lane geometry, signal/sign recognition and weather/degradation classifiers as task-specific models. Track per-class precision/recall, AP at defined IoU thresholds, distance-stratified localization error, occlusion slices, calibration and inference latency. Compare camera-only and multimodal baselines to quantify the contribution of LiDAR/radar.

## Sensor fusion and state estimation

Begin with timestamp health, extrinsic/intrinsic calibration metadata, coordinate transforms and deterministic one-to-one association. Upgrade to probabilistic association and covariance-aware tracking after establishing baseline error. Log sensor dropouts, clock skew and transform provenance. Do not fuse measurements from mismatched coordinate frames or stale timestamps without explicit handling.

## Behaviour prediction

Train temporal encoders and interaction-aware models using actor histories and map context. Predict multiple plausible futures with probabilities, rather than one unqualified future. Evaluate ADE, FDE, miss rate, NLL and calibration across actor classes and interaction types. Split data by scene/map/time to avoid leakage. Ensure inference-time inputs do not contain future annotation labels.

## World models

Train latent dynamics against observed simulator transitions. Evaluate one-step transition quality separately from long-horizon rollout divergence. Track compounding error, physical plausibility, occupancy/geometry consistency and domain shift. Compare rollouts with CARLA ground truth and reject unsupported extrapolations.

## Scenario discovery and adversarial generation

Start with seeded constrained sampling, scenario mutation lineage and coverage measurement. Later add search-based rare-event discovery. Every generated scenario must pass parameter-range checks and simulator validation. Preserve parent scenario, mutation operators, random seed and simulator build for replay.

## Planning and learning

Use deterministic baseline planners and behaviour cloning as interpretable starting points. Reinforcement learning should run in simulation only with declared reward components, bounded actions, reset logic and held-out scenarios. Report whether a result improves task performance at the expense of comfort, rule adherence or safety metrics.

## Research intelligence

Language models can retrieve, organize and draft evidence-linked research notes. Claims must retain references and be reviewable. Generated hypotheses are proposals; only pre-registered experiments and benchmark results count as evidence.
