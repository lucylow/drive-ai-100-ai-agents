# Model card

- Model name/version:
- Architecture and parameter count:
- Training data/version/license:
- Code commit and training configuration:
- Intended task and domain:
- Input schema, units and coordinate frame:
- Output schema:
- Evaluation data split and metrics:
- Calibration/uncertainty method:
- Robustness and stress testing:
- Latency/resource profile:
- Known failure modes and OOD behaviour:
- Checkpoint checksum and reproduction steps:
- Review status:
