# Implementation map

| Concern | Code entry point |
|---|---|
| Full 100-agent catalog | `driveai100/catalog.py` and `agent_catalog.json` |
| Agent runtime interface | `driveai100/core/agent.py` |
| Common task/result contracts | `driveai100/core/contracts.py` |
| Agent registration | `driveai100/core/registry.py` |
| Shared blackboard | `driveai100/core/blackboard.py` |
| Asynchronous event bus | `driveai100/core/message_bus.py` |
| Scheduling/retries | `driveai100/core/runtime.py` |
| Family execution logic | `driveai100/agents/handlers.py` |
| Individual agent modules | `driveai100/agents/individual/agent_*.py` |
| Temporal tracking baseline | `driveai100/fusion/tracking.py` |
| Multimodal forecasting model | `driveai100/ml/models.py` |
| Scenario generator/mutator | `driveai100/scenarios/` |
| Independent checks | `driveai100/safety/verifier.py` |
| Reproducibility | `driveai100/evaluation/reproducibility.py` |
| Simulator integration | `driveai100/integrations/carla.py` |
| ROS topic contracts | `driveai100/integrations/ros2_contract.py` |
| Demo | `python -m driveai100.cli demo` |
