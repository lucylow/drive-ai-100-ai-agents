# DRIVEAI 100 mock-data environment

The project includes a deterministic mock-data service for demonstrations and research-interface development. Every record is synthetic and returned with `synthetic: true` and `label: DEMO / SIMULATED`; these values are not live vehicle telemetry, trained-model performance, or a safety certification.

`MockDataService(seed=42)` builds 100 agent records from the existing catalog, keeping agent IDs, divisions, responsibilities, and model execution modes consistent with the backend. Each agent record includes workload, confidence, latency, task history, dependencies, typed inputs and outputs, error logs, and performance fields. The same dataset also includes linked urban and highway simulation sessions, sensor observations, tracks, predicted trajectories, model-training runs, safety events, DRIVEBENCH-style comparisons, and a reproducible activity timeline.

The API adds three additive endpoints: `GET /mock-data` returns the current seeded snapshot, `POST /mock-data/reset` restores seed 42, and `POST /mock-data/scenario` advances the deterministic scenario offset and returns the next demo session. Existing `/health`, `/agents`, `/catalog/validate`, `/agent-health`, and `/demo` behavior remains available.

The UI's Demo Mode toggle controls whether the synthetic service is loaded. Reset restores the original dataset, while the Simulation Lab's load button generates the next linked scenario. When Demo Mode is disabled, the interface shows catalog-backed data only and does not invent runtime metrics.
